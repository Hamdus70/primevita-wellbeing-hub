
export type UserRole = 'patient' | 'doctor' | 'nurse' | 'physiotherapist' | 'caregiver' | 'admin';

export interface Profile {
  id: string;
  full_name: string;
  role: UserRole;
  email: string;
  phone?: string;
  avatar_url?: string;
  created_at: string;
}

export interface Patient {
  id: string;
  profile_id?: string;
  full_name: string;
  date_of_birth: string;
  gender: string;
  address?: string;
  emergency_contact_name?: string;
  emergency_contact_phone?: string;
  blood_group?: string;
  genotype?: string;
  allergies?: string[];
  medical_history?: string;
  current_medications?: string;
  assigned_staff: string[];
  next_appointment_date?: string;
  hospital_name?: string;
  clinic_type?: string;
  status: 'active' | 'inactive' | 'pending';
  created_at: string;
}

export type LogType = 
  | 'vital_signs' 
  | 'positioning' 
  | 'daily_activity' 
  | 'daily_report' 
  | 'clinical_note' 
  | 'physio_session' 
  | 'prescription'
  | 'doctor_advice';

export interface DocumentationLog {
  id: string;
  patient_id: string;
  staff_id: string;
  role: UserRole;
  log_type: LogType;
  content: any;
  created_at: string;
}

export interface VitalSigns {
  temp: number;
  pulse: number;
  resp: number;
  bp_sys: number;
  bp_dia: number;
  spo2: number;
  glucose?: number;
}

export interface Prescription {
  drugs: Array<{
    name: string;
    dose: string;
    frequency: string;
    duration: string;
  }>;
}

export interface PhysioSession {
  arrival_time: string;
  exit_time: string;
  procedure_details: string;
}

export interface Appointment {
  id: string;
  patient_id: string;
  staff_id?: string;
  scheduled_at: string;
  status: 'scheduled' | 'completed' | 'cancelled' | 'missed';
  location?: string;
  clinic_type?: string;
  notes?: string;
  reminders_sent: {
    '2d': boolean;
    '1d': boolean;
    '0d': boolean;
  };
}

export interface Application {
  id: string;
  type: 'staff' | 'patient';
  status: 'pending' | 'approved' | 'rejected';
  data: any;
  reviewed_by?: string;
  rejection_reason?: string;
  created_at: string;
}
