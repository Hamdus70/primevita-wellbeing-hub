
import { Outlet, Link, useNavigate, createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { 
  HeartPulse, 
  LayoutDashboard, 
  Users, 
  ClipboardList, 
  Calendar, 
  Settings, 
  LogOut, 
  Menu, 
  X,
  Stethoscope,
  Activity,
  UserCircle,
  ShieldCheck,
  FileText,
  Search
} from "lucide-react";
import { motion } from "motion/react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/dashboard")({
  component: DashboardLayout,
});

function DashboardLayout() {
  const { user, profile, loading } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      navigate({ to: "/login" });
    }
  }, [user, loading, navigate]);

  const handleLogout = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      toast.success("Logged out successfully");
      navigate({ to: "/" });
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <HeartPulse className="h-12 w-12 text-primary animate-pulse" />
          <p className="text-muted-foreground animate-pulse">Initializing your portal...</p>
        </div>
      </div>
    );
  }

  if (!user) return null;

  const roleNavItems: Record<string, { to: string; label: string; icon: any }[]> = {
    admin: [
      { to: "/dashboard/admin", label: "Overview", icon: LayoutDashboard },
      { to: "/dashboard/applications", label: "Applications", icon: FileText },
      { to: "/dashboard/staff", label: "Patients", icon: Users },
      { to: "/dashboard/account", label: "Account", icon: UserCircle },
      { to: "/dashboard/vitals", label: "Vitals", icon: Activity },
      { to: "/dashboard/clinical-notes", label: "Clinical Notes", icon: Stethoscope },
      { to: "/dashboard/physio-sessions", label: "Physio Logs", icon: ClipboardList },
      { to: "/dashboard/appointments", label: "Schedule", icon: Calendar },
    ],
    doctor: [
      { to: "/dashboard/staff", label: "My Patients", icon: Users },
      { to: "/dashboard/account", label: "Account", icon: UserCircle },
      { to: "/dashboard/appointments", label: "Appointments", icon: Calendar },
      { to: "/dashboard/clinical-notes", label: "Clinical Notes", icon: Stethoscope },
      { to: "/dashboard/vitals", label: "Vital Signs", icon: Activity },
    ],
    nurse: [
      { to: "/dashboard/staff", label: "Patient List", icon: Users },
      { to: "/dashboard/account", label: "Account", icon: UserCircle },
      { to: "/dashboard/vitals", label: "Vitals Signs", icon: Activity },
      { to: "/dashboard/appointments", label: "Schedule", icon: Calendar },
    ],
    caregiver: [
      { to: "/dashboard/staff", label: "Patients", icon: Users },
      { to: "/dashboard/account", label: "Account", icon: UserCircle },
      { to: "/dashboard/vitals", label: "Vitals Log", icon: Activity },
      { to: "/dashboard/appointments", label: "Duty Schedule", icon: Calendar },
    ],
    physiotherapist: [
      { to: "/dashboard/staff", label: "Patients", icon: Users },
      { to: "/dashboard/account", label: "Account", icon: UserCircle },
      { to: "/dashboard/physio-sessions", label: "Physio Logs", icon: Activity },
      { to: "/dashboard/appointments", label: "Schedule", icon: Calendar },
    ],
    patient: [
      { to: "/dashboard/patient", label: "Health Hub", icon: UserCircle },
      { to: "/dashboard/account", label: "Account", icon: UserCircle },
      { to: "/dashboard/appointments", label: "My Visits", icon: Calendar },
    ]
  };

  const navItems = roleNavItems[profile?.role || "patient"] || roleNavItems.patient;

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex">
      {/* Sidebar */}
      <aside 
        className={`fixed inset-y-0 left-0 z-50 w-72 bg-white border-r border-border transform transition-transform duration-300 ease-in-out ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } md:relative md:translate-x-0 flex flex-col`}
      >
        <div className="p-8 flex items-center gap-4">
          <div className="h-12 w-12 rounded-xl bg-primary flex items-center justify-center shadow-lg shadow-primary/20 shrink-0">
            <Stethoscope className="h-7 w-7 text-white" />
          </div>
          <div className="leading-tight">
            <div className="font-display font-bold text-xl text-deep capitalize">{profile?.role || "User"} Portal</div>
            <div className="text-[10px] uppercase font-bold tracking-[0.1em] text-muted-foreground">PrimeVita Health</div>
          </div>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-2">
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="flex items-center gap-4 px-5 py-4 rounded-2xl transition-all font-medium text-[#94A3B8] hover:bg-secondary/50 hover:text-deep group"
              activeProps={{ className: "bg-[#EBF7F4] text-primary shadow-sm !opacity-100" }}
            >
              <item.icon className="h-5 w-5 transition-colors group-[.text-primary]:text-primary" />
              <span className="text-sm tracking-tight">{item.label}</span>
              <motion.div 
                layoutId="active-pill" 
                className="hidden group-[.text-primary]:block absolute right-0 w-1.5 h-8 bg-primary rounded-l-full" 
              />
            </Link>
          ))}
          
          <div className="pt-8 mt-8 border-t border-border">
            <Link 
              to="/"
              className="flex items-center gap-4 px-5 py-4 rounded-2xl transition-all font-medium text-[#94A3B8] hover:bg-secondary/50 hover:text-deep"
            >
              <LayoutDashboard className="h-5 w-5" />
              <span className="text-sm">Landing Page</span>
            </Link>
          </div>
        </nav>

        <div className="p-6 mt-auto">
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all font-bold text-[#FF5A5A] hover:bg-red-50"
          >
            <LogOut className="h-5 w-5" />
            <span className="text-sm">Log Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        <header className="h-24 bg-white/80 backdrop-blur border-b border-border px-8 flex items-center justify-between sticky top-0 z-40">
          <div className="flex items-center gap-6">
            <button 
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="md:hidden p-2 text-muted-foreground hover:bg-secondary rounded-xl"
            >
              <Menu className="h-6 w-6" />
            </button>
            <h1 className="text-2xl font-display font-bold text-deep tracking-tight">
              {profile?.role === 'admin' ? 'Overview' : `${profile?.role} Hub`}
            </h1>
          </div>

          <div className="flex items-center gap-8">
            <div className="relative group">
               <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
               <input 
                type="text" 
                placeholder="Search..." 
                className="pl-10 pr-4 py-2.5 bg-secondary/50 border border-transparent rounded-full text-sm outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all w-48 md:w-64"
               />
            </div>
            
            <div className="h-10 w-px bg-border hidden md:block" />
            
            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <div className="text-sm font-bold text-deep leading-none">{profile?.full_name || "Account"}</div>
                <div className="text-[10px] font-bold text-primary tracking-widest uppercase mt-1">AID</div>
              </div>
              <div className="h-12 w-12 rounded-full border-2 border-primary/20 p-0.5 shadow-sm">
                 <div className="h-full w-full rounded-full bg-gradient-primary flex items-center justify-center text-white text-lg font-bold">
                    {profile?.full_name?.charAt(0) || "U"}
                 </div>
              </div>
            </div>
          </div>
        </header>

        <section className="p-8 max-w-[1600px] mx-auto w-full">
          <Outlet />
        </section>
      </main>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden" 
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
