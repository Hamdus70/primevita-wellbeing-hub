
import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { UserPlus, HeartPulse, Send, Loader2, CheckCircle2, User, Mail, Phone, FileText, ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { motion, AnimatePresence } from "motion/react";

export const Route = createFileRoute("/apply/")({
  component: ApplicationPortal,
});

function ApplicationPortal() {
  const [activeTab, setActiveTab] = useState<"staff" | "patient">("staff");
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  
  // Staff Form State
  const [staffData, setStaffData] = useState({
    full_name: "",
    email: "",
    phone: "",
    role_applying_for: "nurse",
    qualifications: "",
  });

  // Patient Form State
  const [patientData, setPatientData] = useState({
    full_name: "",
    email: "",
    phone: "",
    reason_for_care: "",
  });

  const handleStaffSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { error } = await supabase.from("applications").insert({
        type: "staff",
        data: staffData,
        status: "pending"
      });
      if (error) throw error;
      setSubmitted(true);
      toast.success("Staff application submitted!");
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePatientSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { error } = await supabase.from("applications").insert({
        type: "patient",
        data: patientData,
        status: "pending"
      });
      if (error) throw error;
      setSubmitted(true);
      toast.success("Patient intake submitted!");
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <SiteHeader />
        <main className="flex-1 flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-md w-full text-center space-y-6"
          >
            <div className="mx-auto w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center text-primary">
              <CheckCircle2 className="h-12 w-12" />
            </div>
            <h1 className="text-3xl font-display font-bold text-deep">Submission Successful!</h1>
            <p className="text-muted-foreground leading-relaxed">
              {activeTab === "staff" 
                ? "Thank you for applying. Our team will review your credentials and get back to you soon."
                : "Thank you for your interest. A care manager will contact you shortly to discuss your needs."}
            </p>
            <Link 
              to="/"
              className="inline-flex items-center gap-2 rounded-full bg-gradient-primary text-primary-foreground px-8 py-3.5 text-sm font-semibold shadow-soft hover:shadow-glow transition-all"
            >
              Back to Main Site
            </Link>
          </motion.div>
        </main>
        <SiteFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col font-sans">
      <SiteHeader />
      <main className="flex-1 py-20 px-4 md:px-8 bg-[#F8FAFC]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-20 animate-in fade-in slide-in-from-top-4 duration-700">
            <h1 className="text-5xl md:text-6xl font-display font-black text-deep mb-6 tracking-tight">Application Portal</h1>
            <p className="text-[#64748B] max-w-2xl mx-auto text-xl font-medium">
              Choose the type of application you'd like to proceed with.
            </p>
          </div>
 
          <div className="grid md:grid-cols-2 gap-10 max-w-5xl mx-auto">
            {/* Staff Card */}
            <motion.div 
              whileHover={{ y: -10 }}
              className="bg-white rounded-[3rem] p-10 border border-border shadow-soft flex flex-col items-center text-center transition-all hover:shadow-glow relative overflow-hidden group"
            >
              <div className="h-24 w-24 rounded-[2rem] bg-[#EBF7F4] flex items-center justify-center text-primary mb-8 group-hover:scale-110 transition-transform">
                 <UserPlus className="h-10 w-10" />
              </div>
              <h2 className="text-2xl font-display font-bold text-deep mb-4 uppercase tracking-widest">Staff Application</h2>
              <p className="text-[#64748B] mb-10 text-lg leading-relaxed flex-1">
                Are you a medical professional looking to join our elite caregivers? We welcome Doctors, Nurses, and specialists.
              </p>
              <Link 
                to="/apply/staff"
                className="w-full py-5 rounded-2xl bg-primary text-white font-black text-lg shadow-glow hover:bg-emerald-600 transition-all uppercase tracking-[0.2em] flex items-center justify-center gap-3"
              >
                Apply Now <Send className="h-5 w-5" />
              </Link>
            </motion.div>

            {/* Patient Card */}
            <motion.div 
              whileHover={{ y: -10 }}
              className="bg-white rounded-[3rem] p-10 border border-border shadow-soft flex flex-col items-center text-center transition-all hover:shadow-glow relative overflow-hidden group"
            >
              <div className="h-24 w-24 rounded-[2rem] bg-indigo-50 flex items-center justify-center text-indigo-600 mb-8 group-hover:scale-110 transition-transform">
                 <HeartPulse className="h-10 w-10" />
              </div>
              <h2 className="text-2xl font-display font-bold text-deep mb-4 uppercase tracking-widest">Patient Application</h2>
              <p className="text-[#64748B] mb-10 text-lg leading-relaxed flex-1">
                Begin your journey to recovery with clinical excellence. Simple registration for homecare and skilled nursing services.
              </p>
              <Link 
                to="/apply/patient"
                className="w-full py-5 rounded-2xl bg-deep text-white font-black text-lg shadow-glow hover:bg-black transition-all uppercase tracking-[0.2em] flex items-center justify-center gap-3"
              >
                Apply Now <Send className="h-5 w-5" />
              </Link>
            </motion.div>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}

function SelectionCard({ active, icon, title, description, onClick, id }: { active: boolean; icon: React.ReactNode; title: string; description: string; onClick: () => void; id: string }) {
  return (
    <button 
      id={id}
      onClick={onClick}
      className={`relative flex items-center gap-6 p-8 rounded-3xl border transition-all text-left group ${
        active 
          ? "bg-primary text-primary-foreground border-primary shadow-glow ring-4 ring-primary/10" 
          : "bg-card text-foreground border-border hover:border-primary/30 hover:bg-secondary/50"
      }`}
    >
      <div className={`h-14 w-14 rounded-2xl flex items-center justify-center shrink-0 transition-colors ${
        active ? "bg-white/20 text-white" : "bg-secondary text-primary group-hover:bg-primary/10"
      }`}>
        {icon}
      </div>
      <div>
        <h3 className="text-xl font-display font-semibold mb-1">{title}</h3>
        <p className={`text-sm leading-relaxed ${active ? "text-primary-foreground/80" : "text-muted-foreground"}`}>{description}</p>
      </div>
      {active && (
        <motion.div 
          layoutId="active-indicator"
          className="absolute inset-0 rounded-3xl bg-gradient-to-br from-white/10 to-transparent pointer-events-none" 
        />
      )}
    </button>
  );
}

function FormField({ label, icon, placeholder, type = "text", value, onChange, options, id }: { label: string; icon?: React.ReactNode; placeholder: string; type?: string; value: string; onChange: (v: string) => void; options?: string[]; id: string }) {
  return (
    <div className="space-y-2.5">
      <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
         {label}
      </label>
      <div className="relative group">
        {icon && (
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground group-focus-within:text-primary transition-colors">
            {icon}
          </div>
        )}
        {type === "textarea" ? (
          <textarea
            id={id}
            required
            placeholder={placeholder}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-full pl-4 pr-4 py-4 min-h-[140px] rounded-2xl bg-secondary/30 border border-border outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-background transition-all resize-none"
          />
        ) : type === "select" ? (
          <select
            id={id}
            required
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-full pl-4 pr-10 py-4 rounded-2xl bg-secondary/30 border border-border outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-background transition-all appearance-none"
          >
            {options?.map(o => (
              <option key={o} value={o}>{o}</option>
            ))}
          </select>
        ) : (
          <input
            id={id}
            required
            type={type}
            placeholder={placeholder}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className={`w-full ${icon ? "pl-11" : "pl-4"} pr-4 py-4 rounded-2xl bg-secondary/30 border border-border outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-background transition-all`}
          />
        )}
      </div>
    </div>
  );
}

function SubmitButton({ loading, id }: { loading: boolean; id: string }) {
  return (
    <button
      id={id}
      type="submit"
      disabled={loading}
      className="w-full py-5 rounded-2xl bg-primary text-primary-foreground font-bold text-lg shadow-glow hover:translate-y-[-2px] transition-all flex items-center justify-center gap-3 disabled:opacity-70 disabled:translate-y-0"
    >
      {loading ? (
        <Loader2 className="h-6 w-6 animate-spin" />
      ) : (
        <>
          Submit Application <Send className="h-5 w-5" />
        </>
      )}
    </button>
  );
}
