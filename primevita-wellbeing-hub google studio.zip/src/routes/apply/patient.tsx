
import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { Send, Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { motion } from "motion/react";

export const Route = createFileRoute("/apply/patient")({
  component: PatientApplyPage,
});

function PatientApplyPage() {
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    phone: "",
    date_of_birth: "",
    gender: "Male",
    address: "",
    service_interested_in: "Skilled Nursing",
    medical_condition_summary: "",
    emergency_contact: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase.from("applications").insert({
        type: "patient",
        data: formData,
        status: "pending"
      });

      if (error) throw error;
      setSubmitted(true);
      toast.success("Application submitted successfully!");
    } catch (error: any) {
      toast.error(error.message || "Failed to submit application");
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <SiteHeader />
        <main className="flex-1 flex items-center justify-center p-4">
          <div className="max-w-md w-full text-center space-y-6">
            <div className="mx-auto w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center text-primary">
              <CheckCircle2 className="h-12 w-12" />
            </div>
            <h1 className="text-3xl font-display font-bold text-deep">Application Received!</h1>
            <p className="text-muted-foreground">
              Thank you for choosing PrimeVita. Our clinical team will review your information and contact you shortly.
            </p>
            <button 
              onClick={() => window.location.href = "/"}
              className="inline-flex items-center gap-2 rounded-full bg-gradient-primary text-primary-foreground px-8 py-3.5 text-sm font-semibold shadow-soft"
            >
              Back to Home
            </button>
          </div>
        </main>
        <SiteFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col font-sans">
      <SiteHeader />
      <main className="flex-1 py-16 px-4">
        <div className="max-w-4xl mx-auto">
          {/* Header Breadcrumb */}
          <div className="flex items-center gap-4 mb-12">
             <Link to="/apply" className="h-12 px-6 rounded-2xl bg-white border border-border flex items-center justify-center text-sm font-bold text-muted-foreground hover:text-primary hover:border-primary transition-all shadow-sm">
                Application Portal
             </Link>
             <div className="h-0.5 w-6 bg-border" />
             <div className="h-12 px-8 rounded-2xl bg-white border border-primary flex items-center justify-center text-sm font-black text-primary shadow-glow uppercase tracking-widest">
                Patient Registration
             </div>
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[3rem] border border-border shadow-soft overflow-hidden"
          >
            <div className="p-10 border-b border-border/50 bg-[#FBFDFF]">
               <h1 className="text-3xl font-display font-bold text-deep">Patient Registration</h1>
               <p className="text-muted-foreground mt-2">Request clinical homecare and nursing services.</p>
            </div>

            <form onSubmit={handleSubmit} className="p-10 space-y-10">
              <div className="grid md:grid-cols-2 gap-10">
                <ApplyField 
                  label="PATIENT FULL NAME" 
                  placeholder="Enter your full name"
                  value={formData.full_name}
                  onChange={(v: string) => setFormData({...formData, full_name: v})}
                />
                <ApplyField 
                  label="PHONE NUMBER" 
                  placeholder="+234..."
                  type="tel"
                  value={formData.phone}
                  onChange={(v: string) => setFormData({...formData, phone: v})}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-10">
                <ApplyField 
                  label="HOME ADDRESS" 
                  placeholder="Where should care be delivered?"
                  value={formData.address}
                  onChange={(v: string) => setFormData({...formData, address: v})}
                />
                <ApplyField 
                  label="EMAIL ADDRESS" 
                  placeholder="name@example.com"
                  type="email"
                  value={formData.email}
                  onChange={(v: string) => setFormData({...formData, email: v})}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-10">
                <ApplyField 
                  label="SERVICE REQUESTED" 
                  type="select"
                  options={["Skilled Nursing", "Physiotherapy", "Elderly Personal Care", "Post-Operative Recovery"]}
                  value={formData.service_interested_in}
                  onChange={(v: string) => setFormData({...formData, service_interested_in: v})}
                />
                <ApplyField 
                  label="DATE OF BIRTH" 
                  type="date"
                  value={formData.date_of_birth}
                  onChange={(v: string) => setFormData({...formData, date_of_birth: v})}
                />
              </div>

              <ApplyField 
                label="MEDICAL SUMMARY" 
                type="textarea"
                placeholder="Describe current medical condition and history..."
                value={formData.medical_condition_summary}
                onChange={(v: string) => setFormData({...formData, medical_condition_summary: v})}
              />

              <button
                type="submit"
                disabled={loading}
                className="w-full py-6 rounded-2xl bg-deep text-white font-black text-xl shadow-glow hover:bg-black transition-all uppercase tracking-[0.2em] flex items-center justify-center gap-4 disabled:opacity-70"
              >
                {loading ? <Loader2 className="h-6 w-6 animate-spin" /> : <>REGISTER <Send className="h-5 w-5" /></>}
              </button>
            </form>
          </motion.div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}

function ApplyField({ label, placeholder, type = "text", value, onChange, options }: any) {
  return (
    <div className="space-y-4 font-sans">
      <label className="text-[10px] font-black text-[#94A3B8] uppercase tracking-[0.2em]">{label}</label>
      <div className="relative group">
        {type === "textarea" ? (
          <textarea
            required
            placeholder={placeholder}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-full px-6 py-5 min-h-[160px] rounded-2xl bg-secondary/20 border border-border outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-background transition-all resize-none text-deep font-semibold"
          />
        ) : type === "select" ? (
          <select
            required
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-full px-6 py-5 rounded-2xl bg-secondary/20 border border-border outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-background transition-all appearance-none text-deep font-semibold"
          >
            {options?.map((o: any) => (
              <option key={o} value={o}>{o}</option>
            ))}
          </select>
        ) : (
          <input
            required
            type={type}
            placeholder={placeholder}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-full px-6 py-5 rounded-2xl bg-secondary/20 border border-border outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-background transition-all text-deep font-semibold"
          />
        )}
      </div>
    </div>
  );
}
