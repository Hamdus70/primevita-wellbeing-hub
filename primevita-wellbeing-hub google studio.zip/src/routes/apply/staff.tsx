
import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { User, Briefcase, FileText, Send, Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { motion } from "motion/react";

export const Route = createFileRoute("/apply/staff")({
  component: StaffApplyPage,
});

function StaffApplyPage() {
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    phone: "",
    address: "",
    dob: "",
    role_applying_for: "Skilled Nurse",
    years_of_experience: "",
    qualifications: "",
    resume_link: "",
    cover_letter: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase.from("applications").insert({
        type: "staff",
        data: formData,
        status: "pending"
      });

      if (error) throw error;
      setSubmitted(true);
      toast.success("Application submitted successfully!");
    } catch (error: any) {
      toast.error(error.message || "Failed to submit application");
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <SiteHeader />
        <main className="flex-1 flex items-center justify-center p-4">
          <div className="max-w-md w-full text-center space-y-6">
            <div className="mx-auto w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center text-primary">
              <CheckCircle2 className="h-12 w-12" />
            </div>
            <h1 className="text-3xl font-display font-bold text-deep">Application Received!</h1>
            <p className="text-muted-foreground">
              Thank you for applying to join the PrimeVita team. Our HR department will review your application and contact you soon.
            </p>
            <button 
              onClick={() => window.location.href = "/"}
              className="inline-flex items-center gap-2 rounded-full bg-gradient-primary text-primary-foreground px-8 py-3 text-sm font-semibold shadow-soft"
            >
              Back to Home
            </button>
          </div>
        </main>
        <SiteFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col font-sans">
      <SiteHeader />
      <main className="flex-1 py-16 px-4">
        <div className="max-w-4xl mx-auto">
          {/* Header Breadcrumb */}
          <div className="flex items-center gap-4 mb-12">
             <Link to="/apply" className="h-12 px-6 rounded-2xl bg-white border border-border flex items-center justify-center text-sm font-bold text-muted-foreground hover:text-primary hover:border-primary transition-all shadow-sm">
                Application Portal
             </Link>
             <div className="h-0.5 w-6 bg-border" />
             <div className="h-12 px-8 rounded-2xl bg-white border border-primary flex items-center justify-center text-sm font-black text-primary shadow-glow uppercase tracking-widest">
                Staff Details
             </div>
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[3rem] border border-border shadow-soft overflow-hidden"
          >
            <div className="p-10 border-b border-border/50 bg-[#FBFDFF]">
               <h1 className="text-3xl font-display font-bold text-deep">Work with Us</h1>
               <p className="text-muted-foreground mt-2">Please provide your professional information below.</p>
            </div>

            <form onSubmit={handleSubmit} className="p-10 space-y-10">
              <div className="grid md:grid-cols-2 gap-10">
                <ApplyField 
                  label="STAFF FULL NAME" 
                  placeholder="Enter your full name"
                  value={formData.full_name}
                  onChange={(v) => setFormData({...formData, full_name: v})}
                />
                <ApplyField 
                  label="PHONE NUMBER" 
                  placeholder="+234..."
                  type="tel"
                  value={formData.phone}
                  onChange={(v) => setFormData({...formData, phone: v})}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-10">
                <ApplyField 
                  label="ADDRESS" 
                  placeholder="Enter residential address"
                  value={formData.address}
                  onChange={(v) => setFormData({...formData, address: v})}
                />
                <ApplyField 
                  label="EMAIL ADDRESS" 
                  placeholder="name@example.com"
                  type="email"
                  value={formData.email}
                  onChange={(v) => setFormData({...formData, email: v})}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-10">
                <ApplyField 
                  label="JOB CATEGORY" 
                  type="select"
                  options={["Medical Doctor", "Skilled Nurse", "Professional Caregiver", "Physiotherapist"]}
                  value={formData.role_applying_for}
                  onChange={(v) => setFormData({...formData, role_applying_for: v})}
                />
                <ApplyField 
                  label="DATE OF BIRTH" 
                  type="date"
                  value={formData.dob}
                  onChange={(v) => setFormData({...formData, dob: v})}
                />
              </div>

              <ApplyField 
                label="QUALIFICATIONS / EXPERIENCE" 
                type="textarea"
                placeholder="Describe your medical background and relevant certifications..."
                value={formData.qualifications}
                onChange={(v) => setFormData({...formData, qualifications: v})}
              />

              <div className="space-y-4">
                <label className="text-[10px] font-black text-[#94A3B8] uppercase tracking-[0.2em]">UPLOAD RESUME / CV</label>
                <div className="relative group cursor-pointer">
                  <div className="border-2 border-dashed border-border group-hover:border-primary/50 group-hover:bg-primary/5 rounded-[2rem] p-12 text-center transition-all bg-secondary/20">
                     <div className="h-16 w-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                        <Loader2 className="h-8 w-8 text-primary group-hover:animate-bounce" />
                     </div>
                     <p className="text-sm font-bold text-deep">Drop your CV here or click to browse</p>
                     <p className="text-xs text-muted-foreground mt-1">PDF, DOCX up to 5MB</p>
                  </div>
                  <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-6 rounded-2xl bg-primary text-white font-black text-xl shadow-glow hover:bg-emerald-600 transition-all uppercase tracking-[0.2em] flex items-center justify-center gap-4 disabled:opacity-70"
              >
                {loading ? <Loader2 className="h-6 w-6 animate-spin" /> : <>APPLY <Send className="h-5 w-5" /></>}
              </button>
            </form>
          </motion.div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}

function ApplyField({ label, placeholder, type = "text", value, onChange, options }: any) {
  return (
    <div className="space-y-4 font-sans">
      <label className="text-[10px] font-black text-[#94A3B8] uppercase tracking-[0.2em]">{label}</label>
      <div className="relative group">
        {type === "textarea" ? (
          <textarea
            required
            placeholder={placeholder}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-full px-6 py-5 min-h-[160px] rounded-2xl bg-secondary/20 border border-border outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-background transition-all resize-none text-deep font-semibold"
          />
        ) : type === "select" ? (
          <select
            required
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-full px-6 py-5 rounded-2xl bg-secondary/20 border border-border outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-background transition-all appearance-none text-deep font-semibold"
          >
            {options?.map((o: any) => (
              <option key={o} value={o}>{o}</option>
            ))}
          </select>
        ) : (
          <input
            required
            type={type}
            placeholder={placeholder}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-full px-6 py-5 rounded-2xl bg-secondary/20 border border-border outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-background transition-all text-deep font-semibold"
          />
        )}
      </div>
    </div>
  );
}
