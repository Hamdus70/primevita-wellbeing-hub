
import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { 
  Activity, 
  Plus, 
  Search, 
  User, 
  Clock,
  Save,
  Loader2,
  Trash2,
  ClipboardList,
  Timer
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { Patient, DocumentationLog } from "@/types/emr";
import { toast } from "sonner";
import { motion } from "motion/react";

export const Route = createFileRoute("/dashboard/physio-sessions")({
  component: PhysioSessionsPage,
});

function PhysioSessionsPage() {
  const { user, profile } = useAuth();
  const [patients, setPatients] = useState<Patient[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [logs, setLogs] = useState<DocumentationLog[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  // Form State
  const [arrivalTime, setArrivalTime] = useState("");
  const [exitTime, setExitTime] = useState("");
  const [procedureType, setProcedureType] = useState("");
  const [notes, setNotes] = useState("");

  useEffect(() => {
    fetchPatients();
  }, []);

  useEffect(() => {
    if (selectedPatient) {
      fetchLogs(selectedPatient.id);
    }
  }, [selectedPatient]);

  const fetchPatients = async () => {
    try {
      const { data, error } = await supabase.from('patients').select('*');
      if (error) throw error;
      setPatients(data as Patient[]);
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const fetchLogs = async (patientId: string) => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('documentation_logs')
        .select('*')
        .eq('patient_id', patientId)
        .eq('log_type', 'physio_session')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setLogs(data as DocumentationLog[]);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveSession = async () => {
    if (!selectedPatient || !arrivalTime || !exitTime || !procedureType || !user) {
      toast.error("Please fill all required fields");
      return;
    }
    setIsSaving(true);
    try {
      const { error } = await supabase.from('documentation_logs').insert({
        patient_id: selectedPatient.id,
        staff_id: user.id,
        role: profile?.role || 'physiotherapist',
        log_type: 'physio_session',
        content: { 
          arrival_time: arrivalTime,
          exit_time: exitTime,
          procedure_type: procedureType,
          notes: notes
        }
      });

      if (error) throw error;

      toast.success("Physiotherapy session logged");
      setArrivalTime("");
      setExitTime("");
      setProcedureType("");
      setNotes("");
      if (selectedPatient) fetchLogs(selectedPatient.id);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setIsSaving(false);
    }
  };

  const filteredPatients = patients.filter(p => 
    p.full_name?.toLowerCase().includes(search.toLowerCase())
  );

  if (profile?.role !== 'physiotherapist' && profile?.role !== 'admin') {
    return <div className="p-12 text-center text-muted-foreground italic">Restricted to certified physiotherapists.</div>;
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold text-deep">Physiotherapy Sessions</h1>
        <p className="text-muted-foreground text-sm">Log session times, procedures and patient progress</p>
      </div>

      <div className="grid lg:grid-cols-[300px_1fr] gap-8">
        <aside className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input 
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search patients..." 
              className="w-full bg-card border border-border rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>
          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
            {filteredPatients.map(p => (
              <button
                key={p.id}
                onClick={() => setSelectedPatient(p)}
                className={`w-full text-left p-4 rounded-2xl border transition-all ${selectedPatient?.id === p.id ? "bg-primary border-primary text-white shadow-glow" : "bg-card border-border hover:border-primary/50 text-deep"}`}
              >
                <div className="font-bold text-sm">{p.full_name}</div>
                <div className={`text-[10px] mt-1 opacity-70 ${selectedPatient?.id === p.id ? "text-white" : "text-muted-foreground"}`}>ID: {p.id.slice(0, 8)}</div>
              </button>
            ))}
          </div>
        </aside>

        <main className="space-y-6">
          {!selectedPatient ? (
            <Card className="h-[400px] flex items-center justify-center text-center border-border/50 border-dashed rounded-[3rem] bg-white">
              <div className="space-y-4 max-w-xs">
                <div className="mx-auto h-20 w-20 bg-[#EBF7F4] rounded-full flex items-center justify-center">
                  <Activity className="h-10 w-10 text-primary" />
                </div>
                <p className="text-slate-500 font-bold">Select a patient to document a physiotherapy session.</p>
              </div>
            </Card>
          ) : (
            <>
              <Card className="rounded-[2.5rem] border-slate-200 shadow-soft overflow-hidden bg-white">
                <CardHeader className="p-8 border-b border-slate-100 bg-slate-50/50">
                  <CardTitle className="text-xl font-display font-black text-deep tracking-tight">Log Session: {selectedPatient.full_name}</CardTitle>
                </CardHeader>
                <CardContent className="p-8 space-y-8">
                  <div className="grid sm:grid-cols-2 gap-8">
                    <div className="space-y-3">
                      <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 flex items-center gap-2">
                        <Clock className="h-3 w-3" /> Time of Arrival
                      </label>
                      <input 
                        type="time"
                        value={arrivalTime}
                        onChange={e => setArrivalTime(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 text-sm font-bold text-deep focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-white outline-none transition-all"
                      />
                    </div>
                    <div className="space-y-3">
                      <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 flex items-center gap-2">
                        <Timer className="h-3 w-3" /> Time of Exit
                      </label>
                      <input 
                        type="time"
                        value={exitTime}
                        onChange={e => setExitTime(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 text-sm font-bold text-deep focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-white outline-none transition-all"
                      />
                    </div>
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 flex items-center gap-2">
                      <ClipboardList className="h-3 w-3" /> Type of Procedure
                    </label>
                    <input 
                      value={procedureType}
                      onChange={e => setProcedureType(e.target.value)}
                      placeholder="e.g., Neurological Rehabilitation, Balance Training"
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 text-sm font-bold text-deep focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-white outline-none transition-all"
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Session Notes & Progress</label>
                    <textarea 
                      value={notes}
                      onChange={e => setNotes(e.target.value)}
                      placeholder="Detail patient response, exercises performed, or future plan..."
                      className="w-full min-h-[160px] bg-slate-50 border border-slate-200 rounded-[2rem] p-6 text-sm font-bold text-deep focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-white outline-none transition-all resize-none"
                    />
                  </div>
                  <div className="flex justify-end pt-4">
                    <button 
                      onClick={handleSaveSession}
                      disabled={isSaving || !arrivalTime || !exitTime || !procedureType}
                      className="inline-flex items-center gap-3 bg-primary text-white px-10 py-5 rounded-2xl text-sm font-black shadow-glow hover:bg-emerald-600 transition-all disabled:opacity-50 uppercase tracking-[0.2em]"
                    >
                      {isSaving ? <Loader2 className="h-5 w-5 animate-spin" /> : <Save className="h-5 w-5" />}
                      Log Session
                    </button>
                  </div>
                </CardContent>
              </Card>

              <div className="space-y-6">
                <h2 className="text-2xl font-display font-black text-deep uppercase tracking-widest text-[#94A3B8]">History</h2>
                {isLoading ? (
                  <div className="py-12 flex justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
                ) : logs.length === 0 ? (
                  <div className="text-center text-slate-400 py-20 bg-white border-2 border-dashed border-slate-100 rounded-[3rem]">
                      <p className="font-bold uppercase tracking-widest text-xs">No prior sessions recorded.</p>
                  </div>
                ) : (
                  <div className="grid sm:grid-cols-2 gap-6">
                    {logs.map((log: any) => (
                      <motion.div 
                        key={log.id} 
                        whileHover={{ y: -5 }}
                        className="bg-white rounded-[2.5rem] border border-slate-200 shadow-soft p-8 group transition-all"
                      >
                        <div className="flex items-start justify-between mb-6">
                          <div className="h-14 w-14 rounded-2xl bg-[#EBF7F4] text-primary flex items-center justify-center">
                            <Activity className="h-6 w-6" />
                          </div>
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{new Date(log.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                        </div>
                        <h4 className="font-display font-black text-deep text-lg mb-3 uppercase tracking-tight">{log.content.procedure_type}</h4>
                        <div className="flex gap-4 text-xs font-bold text-slate-500 mb-6">
                          <span className="flex items-center gap-1.5 bg-slate-50 px-3 py-1 rounded-full"><Clock className="h-3 w-3 text-primary" /> {log.content.arrival_time}</span>
                          <span className="flex items-center gap-1.5 bg-slate-50 px-3 py-1 rounded-full"><Timer className="h-3 w-3 text-primary" /> {log.content.exit_time}</span>
                        </div>
                        <p className="text-sm text-slate-600 font-medium leading-relaxed mb-6">{log.content.notes}</p>
                        <div className="pt-6 border-t border-slate-100 flex justify-between items-center">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Physio: {log.staff_id?.slice(0, 6)}</span>
                          <button className="text-red-400 hover:text-red-500 transition-colors"><Trash2 className="h-5 w-5" /></button>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </main>
      </div>
    </div>
  );
}
