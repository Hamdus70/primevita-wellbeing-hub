
import { createFileRoute } from "@tanstack/react-router";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Mail, BadgeCheck, Activity, Edit2, Loader2, User, Phone, MapPin } from "lucide-react";
import { motion } from "motion/react";
import avatar from "@/assets/jimoh.jpg"; // Assuming user might upload this, but for now we'll use a placeholder or the one from the image if I had the asset

export const Route = createFileRoute("/dashboard/account")({
  component: AccountPage,
});

function AccountPage() {
  const { profile, user, loading } = useAuth();

  if (loading) {
    return (
      <div className="py-24 flex justify-center">
        <Loader2 className="h-10 w-10 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
         <h1 className="text-3xl font-display font-bold text-deep tracking-tight">Profile</h1>
      </div>

      <Card className="rounded-[2.5rem] border-border shadow-soft overflow-hidden bg-white">
        {/* Profile Header Banner */}
        <div className="h-64 bg-[#10B981] relative">
           <div className="absolute inset-0 bg-gradient-to-br from-black/10 to-transparent" />
        </div>

        <CardContent className="px-10 pb-12 relative">
          {/* Avatar positioning */}
          <div className="relative -mt-24 mb-6 inline-block">
             <div className="h-48 w-48 rounded-full border-[6px] border-white bg-white shadow-xl overflow-hidden relative group">
                <div className="h-full w-full bg-gradient-primary flex items-center justify-center text-white text-5xl font-bold">
                   {profile?.full_name?.charAt(0) || user?.email?.charAt(0) || "U"}
                </div>
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer">
                   <Edit2 className="h-8 w-8 text-white" />
                </div>
             </div>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="space-y-1">
              <h2 className="text-4xl font-display font-bold text-deep tracking-tight">
                {profile?.full_name || "Jimoh Muhammad Adegoke"}
              </h2>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black tracking-widest text-primary uppercase">AID</span>
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                <span className="text-sm font-semibold text-muted-foreground capitalize">{profile?.role || "Staff"}</span>
              </div>
            </div>
            
            <button className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full border-2 border-primary text-primary font-bold hover:bg-primary hover:text-white transition-all shadow-sm">
              <Edit2 className="h-4 w-4" /> Edit Profile
            </button>
          </div>

          <div className="mt-10 pt-10 border-t border-border/60 grid md:grid-cols-2 gap-12">
             <div className="space-y-8">
                <ProfileItem 
                  label="EMAIL ADDRESS" 
                  value={user?.email || "jimoh@example.com"} 
                  icon={<Mail className="h-5 w-5" />} 
                />
                <ProfileItem 
                   label="EMPLOYEE UID" 
                   value={user?.id || "NDW42YxpgTexnxjMAsYtOEtL8n11"} 
                   icon={<BadgeCheck className="h-5 w-5" />} 
                   mono 
                />
             </div>
             <div className="space-y-8">
                <ProfileItem 
                  label="ASSIGNED CAPACITY" 
                  value="0 Active Patients" 
                  icon={<Activity className="h-5 w-5" />} 
                  highlight
                />
                <ProfileItem 
                  label="CONTACT NUMBER" 
                  value="+234 800 000 0000" 
                  icon={<Phone className="h-5 w-5" />} 
                />
             </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6 pb-12">
         <Card className="rounded-[2.5rem] p-8 border-border shadow-soft bg-white">
            <h3 className="text-lg font-display font-bold text-deep mb-6">Personal Information</h3>
            <div className="space-y-4">
               <div className="flex justify-between items-center py-3 border-b border-border/40">
                  <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Full Name</span>
                  <span className="text-sm font-semibold text-deep">{profile?.full_name || "N/A"}</span>
               </div>
               <div className="flex justify-between items-center py-3 border-b border-border/40">
                  <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Date of Birth</span>
                  <span className="text-sm font-semibold text-deep">Jan 12, 1985</span>
               </div>
               <div className="flex justify-between items-center py-3 border-b border-border/40">
                  <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Gender</span>
                  <span className="text-sm font-semibold text-deep capitalize">{profile?.gender || "Male"}</span>
               </div>
            </div>
         </Card>
         <Card className="rounded-[2.5rem] p-8 border-border shadow-soft bg-white">
            <h3 className="text-lg font-display font-bold text-deep mb-6">Professional Details</h3>
            <div className="space-y-4">
               <div className="flex justify-between items-center py-3 border-b border-border/40">
                  <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Specialization</span>
                  <span className="text-sm font-semibold text-deep capitalize">{profile?.role || "Doctor"}</span>
               </div>
               <div className="flex justify-between items-center py-3 border-b border-border/40">
                  <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Experience</span>
                  <span className="text-sm font-semibold text-deep font-mono">10+ Years</span>
               </div>
               <div className="flex justify-between items-center py-3 border-b border-border/40">
                  <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Availability</span>
                  <span className="text-sm font-bold text-primary">On Duty</span>
               </div>
            </div>
         </Card>
      </div>
    </div>
  );
}

function ProfileItem({ label, value, icon, mono, highlight }: { label: string; value: string; icon: React.ReactNode; mono?: boolean; highlight?: boolean }) {
  return (
    <div className="space-y-4">
      <div className="text-[10px] font-bold text-[#94A3B8] uppercase tracking-[0.2em]">{label}</div>
      <div className={`p-6 rounded-3xl flex items-center justify-between border transition-all ${
        highlight ? "bg-[#EBF7F4] border-primary/20" : "bg-[#F8FAFC] border-border/50"
      }`}>
        <div className={`text-lg font-bold ${mono ? "font-mono text-xs opacity-70" : "text-deep"} ${highlight ? "text-primary" : ""}`}>
          {value}
        </div>
        <div className={highlight ? "text-primary" : "text-[#94A3B8]"}>
          {icon}
        </div>
      </div>
    </div>
  );
}
