
import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { 
  Activity, 
  Thermometer, 
  Heart, 
  Wind, 
  Droplet, 
  Zap, 
  Search,
  CheckCircle2,
  Loader2,
  ArrowRight,
  TrendingUp,
  History,
  Plus
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { Patient } from "@/types/emr";
import { toast } from "sonner";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend
} from 'recharts';
import { format } from "date-fns";
import { motion } from "motion/react";

export const Route = createFileRoute("/dashboard/vitals")({
  component: VitalsLoggingPage,
});

function VitalsLoggingPage() {
  const { user, profile } = useAuth();
  const [patients, setPatients] = useState<Patient[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [vitalsHistory, setVitalsHistory] = useState<any[]>([]);
  const [vitals, setVitals] = useState({
    temp: "",
    pulse: "",
    resp: "",
    bp_sys: "",
    bp_dia: "",
    spo2: "",
    glucose: ""
  });

  useEffect(() => {
    if (profile) {
      fetchPatients();
    }
  }, [profile]);

  useEffect(() => {
    if (selectedPatient) {
      fetchVitalsHistory(selectedPatient.id);
    }
  }, [selectedPatient]);

  const fetchPatients = async () => {
    try {
      let query = supabase.from('patients').select('*').eq('status', 'active');
      
      if (profile?.role !== 'admin' && profile?.id) {
        query = query.contains('assigned_staff', [profile.id]);
      }
      
      const { data, error } = await query;
      if (error) throw error;
      setPatients(data as Patient[]);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const fetchVitalsHistory = async (patientId: string) => {
    try {
      const { data, error } = await supabase
        .from('documentation_logs')
        .select('*')
        .eq('patient_id', patientId)
        .eq('log_type', 'vital_signs')
        .order('created_at', { ascending: true })
        .limit(20);
      
      if (error) throw error;
      
      const formattedData = data.map(log => ({
        ...log.content,
        timestamp: format(new Date(log.created_at || ""), "HH:mm"),
        date: format(new Date(log.created_at || ""), "MMM dd")
      }));
      setVitalsHistory(formattedData);
    } catch (error) {
      console.error(error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatient || !user) return;
    setSubmitting(true);

    try {
      const { error } = await supabase.from('documentation_logs').insert({
        patient_id: selectedPatient.id,
        staff_id: user.id,
        role: profile?.role || 'nurse',
        log_type: 'vital_signs',
        content: {
          temp: parseFloat(vitals.temp),
          pulse: parseInt(vitals.pulse),
          resp: parseInt(vitals.resp),
          bp_sys: parseInt(vitals.bp_sys),
          bp_dia: parseInt(vitals.bp_dia),
          spo2: parseInt(vitals.spo2),
          glucose: vitals.glucose ? parseFloat(vitals.glucose) : null
        }
      });

      if (error) throw error;

      toast.success("Vitals logged successfully!");
      setVitals({ temp: "", pulse: "", resp: "", bp_sys: "", bp_dia: "", spo2: "", glucose: "" });
      fetchVitalsHistory(selectedPatient.id);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-display font-black text-deep tracking-tight">Vitals Dashboard</h1>
          <p className="text-slate-500 mt-1 font-medium">Monitoring and documenting patient health metrics.</p>
        </div>
      </div>

      {!selectedPatient ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
            <div className="col-span-full py-20 flex flex-col items-center justify-center text-slate-400">
              <Loader2 className="h-10 w-10 animate-spin mb-4" />
              <p className="font-bold uppercase tracking-widest text-xs">Fetching assigned patients...</p>
            </div>
          ) : patients.length === 0 ? (
             <div className="col-span-full py-20 text-center bg-white rounded-[2rem] border-2 border-dashed border-slate-200">
                <p className="text-slate-400 font-bold">No active patients found.</p>
             </div>
          ) : patients.map(p => (
            <motion.div 
              key={p.id}
              whileHover={{ scale: 1.02 }}
              onClick={() => setSelectedPatient(p)}
              className="bg-white rounded-[2.5rem] p-6 border border-slate-200 shadow-soft hover:shadow-glow cursor-pointer transition-all"
            >
              <div className="flex items-center gap-5">
                <div className="h-16 w-16 rounded-2xl bg-[#EBF7F4] flex items-center justify-center text-primary font-black text-xl">
                  {p.full_name.split(' ').map(n => n[0]).join('')}
                </div>
                <div className="flex-1">
                  <h3 className="font-display font-bold text-deep text-lg">{p.full_name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                     <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-bold">#{p.id.slice(0,6)}</span>
                     <span className="text-[10px] text-primary font-bold uppercase tracking-widest">Active</span>
                  </div>
                </div>
                <div className="h-10 w-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-400">
                   <ArrowRight className="h-5 w-5" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="space-y-8">
           {/* Active Patient Bar */}
           <div className="bg-white p-4 rounded-[2rem] border border-slate-200 flex items-center justify-between shadow-soft">
              <div className="flex items-center gap-4">
                 <div className="h-12 w-12 rounded-xl bg-primary text-white flex items-center justify-center font-black">
                    {selectedPatient.full_name.charAt(0)}
                 </div>
                 <div>
                    <h2 className="font-display font-bold text-deep">Patient: {selectedPatient.full_name}</h2>
                    <p className="text-xs text-slate-500 font-medium">DOB: {selectedPatient.date_of_birth} | ID: {selectedPatient.id.slice(0,8)}</p>
                 </div>
              </div>
              <button 
                onClick={() => setSelectedPatient(null)}
                className="px-6 py-2 rounded-xl border border-slate-200 text-sm font-bold text-slate-500 hover:bg-slate-50 transition-all uppercase tracking-widest"
              >
                Change
              </button>
           </div>

           <div className="grid lg:grid-cols-3 gap-8">
              {/* Logging Form */}
              <div className="lg:col-span-1 space-y-6">
                 <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-soft overflow-hidden">
                    <div className="p-6 border-b border-slate-100 bg-slate-50/50">
                       <div className="flex items-center gap-3">
                          <Plus className="h-5 w-5 text-primary" />
                          <h3 className="font-display font-bold text-deep">New Vitals Log</h3>
                       </div>
                    </div>
                    <form onSubmit={handleSubmit} className="p-6 space-y-5">
                       <div className="grid grid-cols-2 gap-4">
                          <MiniInput label="Temp (°C)" value={vitals.temp} onChange={v => setVitals({...vitals, temp: v})} />
                          <MiniInput label="Pulse (BPM)" value={vitals.pulse} onChange={v => setVitals({...vitals, pulse: v})} />
                          <MiniInput label="Resp (RPM)" value={vitals.resp} onChange={v => setVitals({...vitals, resp: v})} />
                          <MiniInput label="SpO2 (%)" value={vitals.spo2} onChange={v => setVitals({...vitals, spo2: v})} />
                       </div>
                       <div className="grid grid-cols-2 gap-4">
                          <MiniInput label="BP Sys" value={vitals.bp_sys} onChange={v => setVitals({...vitals, bp_sys: v})} />
                          <MiniInput label="BP Dia" value={vitals.bp_dia} onChange={v => setVitals({...vitals, bp_dia: v})} />
                       </div>
                       <MiniInput label="Blood Glucose (mg/dL)" value={vitals.glucose} onChange={v => setVitals({...vitals, glucose: v})} required={false} />
                       
                       <button 
                         disabled={submitting}
                         className="w-full py-4 rounded-2xl bg-primary text-white font-black text-sm shadow-glow hover:bg-emerald-600 transition-all flex items-center justify-center gap-2 uppercase tracking-widest mt-4"
                       >
                         {submitting ? <Loader2 className="h-5 w-5 animate-spin" /> : "Save Entry"}
                       </button>
                    </form>
                 </div>
              </div>

              {/* Charts & Trends */}
              <div className="lg:col-span-2 space-y-8">
                 <div className="grid md:grid-cols-2 gap-6">
                    <ChartCard title="Heart Pulse" color="#10B981" dataKey="pulse" unit="bpm" data={vitalsHistory} />
                    <ChartCard title="Blood Pressure" color="#6366F1" dataKey="bp_sys" dataKey2="bp_dia" unit="mmHg" data={vitalsHistory} />
                    <ChartCard title="Temperature" color="#F59E0B" dataKey="temp" unit="°C" data={vitalsHistory} />
                    <ChartCard title="Pulse Oximetry" color="#3B82F6" dataKey="spo2" unit="%" data={vitalsHistory} />
                 </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
}

function MiniInput({ label, value, onChange, type = "number", required = true }: any) {
  return (
    <div className="space-y-1.5">
      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{label}</label>
      <input
        required={required}
        type={type}
        step="0.1"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-white transition-all text-sm font-bold text-deep"
      />
    </div>
  );
}

function ChartCard({ title, color, dataKey, dataKey2, unit, data }: any) {
  return (
    <Card className="rounded-[2.5rem] border-slate-200 shadow-soft overflow-hidden">
      <CardHeader className="bg-slate-50/50 border-b border-slate-100 py-4 px-6 flex flex-row items-center justify-between">
        <CardTitle className="text-sm font-display font-bold text-deep uppercase tracking-widest">{title}</CardTitle>
        <TrendingUp className="h-4 w-4 text-slate-300" />
      </CardHeader>
      <CardContent className="p-6">
        <div className="h-48 w-full">
          {data.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis dataKey="timestamp" hide />
                <YAxis hide domain={['auto', 'auto']} />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }} 
                  formatter={(v) => [`${v} ${unit}`]}
                />
                <Line type="monotone" dataKey={dataKey} stroke={color} strokeWidth={4} dot={{ r: 4, strokeWidth: 2, fill: '#fff' }} activeDot={{ r: 6 }} />
                {dataKey2 && <Line type="monotone" dataKey={dataKey2} stroke="#CBD5E1" strokeWidth={2} dot={false} />}
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-slate-300 text-xs font-bold uppercase">No data points</div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
