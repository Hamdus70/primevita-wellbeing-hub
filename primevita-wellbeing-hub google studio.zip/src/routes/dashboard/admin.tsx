
import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { motion } from "motion/react";
import { 
  Users, 
  FileText, 
  UserPlus, 
  TrendingUp, 
  Clock, 
  CheckCircle2,
  AlertCircle,
  Activity,
  History,
  Stethoscope,
  Loader2
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line
} from "recharts";
import { toast } from "sonner";

export const Route = createFileRoute("/dashboard/admin")({
  component: AdminDashboard,
});

const data = [
  { name: 'Mon', apps: 4, visits: 24 },
  { name: 'Tue', apps: 3, visits: 18 },
  { name: 'Wed', apps: 7, visits: 32 },
  { name: 'Thu', apps: 2, visits: 25 },
  { name: 'Fri', apps: 5, visits: 40 },
  { name: 'Sat', apps: 8, visits: 35 },
  { name: 'Sun', apps: 4, visits: 20 },
];

function AdminDashboard() {
  const [stats, setStats] = useState({
    activePatients: 0,
    totalStaff: 0,
    pendingApps: 0,
    upcomingAppointments: 0
  });
  const [recentLogs, setRecentLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
    fetchRecentLogs();
  }, []);

  const fetchStats = async () => {
    try {
      const [{ count: patientsCount }, { count: staffCount }, { count: appsCount }, { count: appointmentsCount }] = await Promise.all([
        supabase.from('patients').select('*', { count: 'exact', head: true }).eq('status', 'active'),
        supabase.from('profiles').select('*', { count: 'exact', head: true }).neq('role', 'patient'),
        supabase.from('applications').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('appointments').select('*', { count: 'exact', head: true }).gte('scheduled_at', new Date().toISOString())
      ]);

      setStats({
        activePatients: patientsCount || 0,
        totalStaff: staffCount || 0,
        pendingApps: appsCount || 0,
        upcomingAppointments: appointmentsCount || 0
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
    }
  };

  const fetchRecentLogs = async () => {
    try {
      // Oversight for all system logs (documentation logs)
      const { data, error } = await supabase
        .from("documentation_logs")
        .select(`
          *,
          patient:patients(full_name),
          staff:profiles(full_name)
        `)
        .order("created_at", { ascending: false })
        .limit(10);

      if (error) throw error;
      setRecentLogs(data || []);
    } catch (error: any) {
      console.error("Error fetching logs:", error);
    } finally {
      setLoading(false);
    }
  };


  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="relative overflow-hidden">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative z-10"
          >
            <h1 className="text-4xl md:text-5xl font-display font-bold text-deep leading-tight">
              Welcome back, <em className="text-primary not-italic">{profile?.full_name?.split(' ')[0] || "Jimoh"}</em>
            </h1>
            <p className="mt-2 text-muted-foreground text-lg">
              Here's what's happening today at PrimeVita Health.
            </p>
          </motion.div>
        </div>

        {/* Total Patients Card - Simplified match to image */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-[2.5rem] border border-border shadow-soft p-8 min-w-[260px] flex items-center gap-6"
        >
          <div className="h-16 w-16 rounded-2xl bg-[#EBF7F4] flex items-center justify-center text-primary">
            <Users className="h-8 w-8" />
          </div>
          <div>
            <div className="text-4xl font-display font-bold text-deep leading-none">{stats.activePatients}</div>
            <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest mt-2 px-1">Total Patients</div>
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 pb-12">
        {/* Recent System Activity Logs */}
        <Card className="rounded-[2.5rem] border-slate-200 shadow-soft overflow-hidden min-h-[500px] bg-white">
          <CardHeader className="p-8 border-b border-slate-50 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-xl font-display font-black text-deep uppercase tracking-tight">System Activity</CardTitle>
              <CardDescription className="text-xs font-bold text-slate-400 mt-1 uppercase tracking-widest">Global Audit Trail</CardDescription>
            </div>
            <div className="h-12 w-12 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-400">
              <History className="h-6 w-6" />
            </div>
          </CardHeader>
          <CardContent className="p-0">
             <div className="max-h-[400px] overflow-y-auto custom-scrollbar">
                {loading ? (
                   <div className="p-12 flex justify-center"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
                ) : recentLogs.length === 0 ? (
                   <div className="p-12 text-center text-slate-400 italic font-medium">No system activities recorded yet.</div>
                ) : (
                  <div className="divide-y divide-slate-50">
                    {recentLogs.map((log) => (
                      <div key={log.id} className="p-6 hover:bg-slate-50 transition-colors group">
                        <div className="flex gap-4">
                          <div className={`h-10 w-10 rounded-xl flex items-center justify-center shrink-0 ${
                            log.log_type === 'clinical_note' ? "bg-emerald-100 text-emerald-600" :
                            log.log_type === 'physio_session' ? "bg-blue-100 text-blue-600" :
                            "bg-amber-100 text-amber-600"
                          }`}>
                            {log.log_type === 'clinical_note' ? <Stethoscope className="h-5 w-5" /> :
                             log.log_type === 'physio_session' ? <Activity className="h-5 w-5" /> :
                             <FileText className="h-5 w-5" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2">
                              <p className="text-sm font-bold text-deep truncate">
                                {log.staff?.full_name || "System Staff"} 
                                <span className="font-medium text-slate-400 mx-1">documented for</span> 
                                {log.patient?.full_name || "Unknown Patient"}
                              </p>
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest shrink-0">
                                {new Date(log.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                            <p className="text-xs text-slate-500 font-medium mt-1 uppercase tracking-tight">
                              Type: <span className="text-primary">{log.log_type.replace('_', ' ')}</span>
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
             </div>
          </CardContent>
          <div className="p-6 bg-slate-50/50 border-t border-slate-100 text-center">
             <Link to="/dashboard/clinical-notes" className="text-[10px] font-black tracking-[0.2em] text-primary uppercase hover:underline">View Full Documentation Registry</Link>
          </div>
        </Card>

        {/* Staff & Patient Census Summary */}
        <Card className="rounded-[2.5rem] border-slate-200 shadow-soft overflow-hidden min-h-[500px] bg-white">
          <CardHeader className="p-8 border-b border-slate-100 flex flex-row items-center justify-between shadow-sm">
            <div>
              <CardTitle className="text-xl font-display font-black text-deep uppercase tracking-tight">Care Census</CardTitle>
              <CardDescription className="text-xs font-bold text-slate-400 mt-1 uppercase tracking-widest">Active Patient Distribution</CardDescription>
            </div>
            <Link 
              to="/dashboard/staff" 
              className="text-[10px] font-black tracking-widest text-primary uppercase bg-[#EBF7F4] px-6 py-3 rounded-2xl hover:bg-primary hover:text-white transition-all shadow-sm"
            >
              VIEW ALL
            </Link>
          </CardHeader>
          <CardContent className="p-8">
             <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                   <div className="p-6 rounded-[2rem] bg-emerald-50/50 border border-emerald-100">
                      <div className="text-2xl font-display font-black text-emerald-600">{stats.activePatients}</div>
                      <div className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mt-1">Active Patients</div>
                   </div>
                   <div className="p-6 rounded-[2rem] bg-blue-50/50 border border-blue-100">
                      <div className="text-2xl font-display font-black text-blue-600">{stats.totalStaff}</div>
                      <div className="text-[10px] font-black text-blue-400 uppercase tracking-widest mt-1">Clinical Staff</div>
                   </div>
                </div>
                
                <div className="h-[250px] mt-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={data}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                      <XAxis 
                        dataKey="name" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#94A3B8', fontSize: 10, fontWeight: 700 }}
                        dy={10}
                      />
                      <YAxis hide />
                      <Tooltip 
                        contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 700 }}
                      />
                      <Bar 
                        dataKey="visits" 
                        fill="#10B981" 
                        radius={[6, 6, 6, 6]} 
                        barSize={32}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <p className="text-center text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] pt-4">Weekly Patient Engagement Volume</p>
             </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon: Icon, trend, color, bgColor }: any) {
  return (
    <Card className="rounded-3xl border-border shadow-soft hover:shadow-glow transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className={`h-12 w-12 ${bgColor} ${color} rounded-2xl flex items-center justify-center`}>
            <Icon className="h-6 w-6" />
          </div>
          <div className="text-right">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">{title}</p>
            <h3 className="text-3xl font-display font-bold text-deep mt-1">{value}</h3>
          </div>
        </div>
        <div className="mt-4 pt-4 border-t border-border/50">
          <p className="text-[10px] font-medium text-muted-foreground">{trend}</p>
        </div>
      </CardContent>
    </Card>
  );
}
