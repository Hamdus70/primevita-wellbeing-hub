
import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { 
  HeartPulse, 
  Activity, 
  Stethoscope, 
  FileText, 
  Calendar, 
  Clock,
  ArrowUpRight,
  TrendingUp,
  AlertCircle
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { Patient, DocumentationLog, VitalSigns } from "@/types/emr";
import { 
  AreaChart,
  Area,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer
} from "recharts";

export const Route = createFileRoute("/dashboard/patient")({
  component: PatientDashboard,
});

function PatientDashboard() {
  const { user } = useAuth();
  const [patientData, setPatientData] = useState<Patient | null>(null);
  const [logs, setLogs] = useState<DocumentationLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchPatientAndLogs();
    }
  }, [user]);

  const fetchPatientAndLogs = async () => {
    setLoading(true);
    try {
      // Get patient record linked to this profile
      const { data: patient, error: pError } = await supabase
        .from('patients')
        .select('*')
        .eq('profile_id', user?.id)
        .maybeSingle();
      
      if (pError) throw pError;
      
      if (patient) {
        setPatientData(patient as Patient);

        // Get logs for this patient
        const { data: lData, error: lError } = await supabase
          .from('documentation_logs')
          .select('*')
          .eq('patient_id', patient.id)
          .order('created_at', { ascending: false });
        
        if (lError) throw lError;
        setLogs(lData as DocumentationLog[]);
      }
    } catch (error) {
      console.error("Error fetching patient data:", error);
    } finally {
      setLoading(false);
    }
  };

  const latestVitalsLog = logs.find(l => l.log_type === 'vital_signs');
  const latestVitals: VitalSigns | null = latestVitalsLog?.content || null;

  const vitalsHistory = logs
    .filter(l => l.log_type === 'vital_signs')
    .slice(0, 7)
    .reverse()
    .map(l => ({
      time: new Date(l.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      temp: l.content.temp,
      spo2: l.content.spo2,
      bp_sys: l.content.bp_sys
    }));

  return (
    <div className="space-y-6">
      {!patientData && !loading ? (
        <Card className="border-amber-200 bg-amber-50 rounded-3xl p-6">
          <div className="flex gap-4">
            <AlertCircle className="h-6 w-6 text-amber-600 shrink-0" />
            <div>
              <h3 className="font-semibold text-amber-900">Patient Record Not Linked</h3>
              <p className="text-sm text-amber-700 mt-1">
                We couldn't find a patient record linked to your account. If you just registered, please wait for admin approval.
              </p>
            </div>
          </div>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <HealthMetric 
              label="Temperature" 
              value={latestVitals?.temp ? `${latestVitals.temp}°C` : "--"} 
              status={latestVitals?.temp && latestVitals.temp > 37.5 ? "high" : "normal"}
              icon={Activity}
            />
            <HealthMetric 
              label="Blood Pressure" 
              value={latestVitals?.bp_sys ? `${latestVitals.bp_sys}/${latestVitals.bp_dia}` : "--"} 
              status="normal"
              icon={HeartPulse}
            />
            <HealthMetric 
              label="SpO2" 
              value={latestVitals?.spo2 ? `${latestVitals.spo2}%` : "--"} 
              status={latestVitals?.spo2 && latestVitals.spo2 < 95 ? "low" : "normal"}
              icon={TrendingUp}
            />
            <HealthMetric 
              label="Blood Glucose" 
              value={latestVitals?.glucose ? `${latestVitals.glucose} mg/dL` : "--"} 
              status="normal"
              icon={Activity}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-[1fr_400px] gap-8">
            <div className="space-y-8">
               <Card className="rounded-[2.5rem] border-slate-200 shadow-soft overflow-hidden bg-white">
                <CardHeader className="p-8 border-b border-slate-100 bg-slate-50/50">
                   <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-xl font-display font-black text-deep uppercase tracking-tight">Health History</CardTitle>
                      <CardDescription className="text-xs font-bold text-slate-400 mt-1 uppercase tracking-widest">Vital Signs Trends</CardDescription>
                    </div>
                    <div className="h-12 w-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                      <TrendingUp className="h-6 w-6" />
                    </div>
                   </div>
                </CardHeader>
                <CardContent className="h-[350px] p-8">
                  {vitalsHistory.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={vitalsHistory}>
                        <defs>
                          <linearGradient id="colorPatient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#10B981" stopOpacity={0.1}/>
                            <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                        <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94A3B8', fontWeight: 700 }} />
                        <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94A3B8', fontWeight: 700 }} />
                        <Tooltip contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 700 }} />
                        <Area type="monotone" dataKey="temp" stroke="#10B981" fillOpacity={1} fill="url(#colorPatient)" strokeWidth={3} />
                      </AreaChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-full flex items-center justify-center text-slate-400 text-xs font-bold uppercase tracking-widest border-2 border-dashed border-slate-100 rounded-[2rem]">
                      Monitoring initializing...
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="rounded-[2.5rem] border-slate-200 shadow-soft overflow-hidden bg-white">
                <CardHeader className="p-8 border-b border-slate-100 bg-slate-50/50">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-xl font-display font-black text-deep uppercase tracking-tight">Clinical Observations</CardTitle>
                      <CardDescription className="text-xs font-bold text-slate-400 mt-1 uppercase tracking-widest">Medical Logs & Summaries</CardDescription>
                    </div>
                    <button className="text-primary text-[10px] font-black uppercase tracking-widest hover:underline bg-emerald-50 px-4 py-2 rounded-full">Archive</button>
                  </div>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="space-y-4">
                    {logs
                      .filter(l => ['doctor_advice', 'clinical_note'].includes(l.log_type))
                      .slice(0, 5)
                      .map(log => (
                      <div key={log.id} className="flex gap-6 p-6 rounded-[2rem] hover:bg-slate-50 transition-all group">
                        <div className="h-14 w-14 rounded-2xl bg-slate-50 text-slate-400 flex items-center justify-center shrink-0 group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                          <Stethoscope className="h-6 w-6" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-display font-black text-deep uppercase tracking-tight">{log.log_type.replace('_', ' ')}</h4>
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest bg-slate-100 px-3 py-1 rounded-full group-hover:bg-primary group-hover:text-white mb-2 transition-colors">
                              {new Date(log.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                            </span>
                          </div>
                          <p className="text-sm text-slate-500 font-medium leading-relaxed">
                            {typeof log.content === 'string' ? log.content : log.content.note || log.content.observation || JSON.stringify(log.content)}
                          </p>
                        </div>
                      </div>
                    ))}
                    {logs.filter(l => ['doctor_advice', 'clinical_note'].includes(l.log_type)).length === 0 && (
                      <div className="text-center py-20 opacity-30">
                        <FileText className="h-12 w-12 mx-auto mb-4" />
                        <p className="text-[10px] font-black uppercase tracking-widest">No clinical summaries yet</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-8">
              <Card className="rounded-[2.5rem] border-slate-200 shadow-soft overflow-hidden bg-white">
                <CardHeader className="p-8 border-b border-slate-100 bg-emerald-500 text-white">
                   <div className="flex items-center justify-between">
                    <CardTitle className="text-lg font-display font-black uppercase tracking-tight">Drug Chart</CardTitle>
                    <Activity className="h-5 w-5 opacity-50" />
                   </div>
                </CardHeader>
                <CardContent className="p-8 space-y-4">
                  {logs.filter(l => l.log_type === 'prescription').slice(0, 3).map(l => (
                    <div key={l.id} className="space-y-3">
                       {l.content.drug ? (
                          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-100 group hover:border-emerald-200 transition-all">
                             <div className="font-black text-deep uppercase text-sm tracking-tight">{l.content.drug}</div>
                             <div className="flex items-center gap-3 mt-2">
                                <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md uppercase tracking-widest">{l.content.dosage}</span>
                                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em]">{l.content.frequency} · {l.content.duration}</span>
                             </div>
                          </div>
                       ) : l.content.drugs?.map((d: any, i: number) => (
                        <div key={i} className="p-5 rounded-2xl bg-slate-50 border border-slate-100 group hover:border-emerald-200 transition-all">
                           <div className="font-black text-deep uppercase text-sm tracking-tight">{d.name}</div>
                           <div className="flex items-center gap-3 mt-2">
                              <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md uppercase tracking-widest">{d.dose}</span>
                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em]">{d.frequency}</span>
                           </div>
                        </div>
                      ))}
                    </div>
                  ))}
                  {logs.filter(l => l.log_type === 'prescription').length === 0 && (
                    <div className="py-12 text-center text-slate-400 text-[10px] font-black uppercase tracking-widest border-2 border-dashed border-slate-100 rounded-3xl">
                      No Active Prescriptions
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="rounded-[2.5rem] border-slate-200 shadow-soft overflow-hidden bg-white">
                <CardHeader className="p-8 border-b border-slate-100 bg-slate-50/50">
                  <CardTitle className="text-lg font-display font-black text-deep uppercase tracking-tight">Current Care Plan</CardTitle>
                </CardHeader>
                <CardContent className="p-8">
                  <div className="flex items-start gap-5">
                    <div className="h-16 w-16 bg-emerald-50 rounded-2xl flex items-center justify-center shrink-0">
                      <Stethoscope className="h-8 w-8 text-primary" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Primary Clinician</p>
                      <h4 className="text-lg font-black text-deep tracking-tight">Dr. Olumide Hassan</h4>
                      <p className="text-xs font-bold text-primary mt-1">Neurology Specialist</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function HealthMetric({ label, value, status, icon: Icon }: any) {
  const statusColors = {
    normal: "bg-emerald-100 text-emerald-700",
    low: "bg-amber-100 text-amber-700",
    high: "bg-rose-100 text-rose-700",
  };

  return (
    <Card className="rounded-2xl border-border shadow-soft overflow-hidden hover:scale-[1.02] transition-transform">
      <CardContent className="p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="h-10 w-10 rounded-xl bg-secondary flex items-center justify-center text-primary">
            <Icon className="h-5 w-5" />
          </div>
          <span className={`text-[8px] font-bold uppercase px-2 py-0.5 rounded-full ${statusColors[status as keyof typeof statusColors]}`}>
            {status}
          </span>
        </div>
        <div className="space-y-0.5">
          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{label}</p>
          <p className="text-2xl font-display font-bold text-deep">{value}</p>
        </div>
      </CardContent>
    </Card>
  );
}
