
import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { 
  Calendar as CalendarIcon, 
  Clock, 
  MapPin, 
  User, 
  Plus, 
  Search, 
  CheckCircle2,
  AlertCircle,
  Bell,
  Loader2
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { Appointment } from "@/types/emr";
import { toast } from "sonner";

export const Route = createFileRoute("/dashboard/appointments")({
  component: AppointmentsPage,
});

function AppointmentsPage() {
  const { user, profile } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile) {
      fetchAppointments();
    }
  }, [profile]);

  const fetchAppointments = async () => {
    setLoading(true);
    try {
      let query = supabase.from('appointments').select('*').order('scheduled_at', { ascending: true });
      
      if (profile?.role === 'patient') {
        const { data: patient, error: pError } = await supabase
          .from('patients')
          .select('id')
          .eq('profile_id', user?.id)
          .maybeSingle();
        
        if (pError) throw pError;
        
        if (patient) {
          query = query.eq('patient_id', patient.id);
        } else {
          setAppointments([]);
          setLoading(false);
          return;
        }
      } else if (profile?.role !== 'admin' && user?.id) {
        query = query.eq('staff_id', user.id);
      }

      const { data, error } = await query;
      if (error) throw error;
      setAppointments(data as Appointment[]);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const upcoming = appointments.filter(a => new Date(a.scheduled_at) > new Date());
  const past = appointments.filter(a => new Date(a.scheduled_at) <= new Date());

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-deep">Care Schedule</h1>
          <p className="text-muted-foreground text-sm">Manage appointments and nursing visits</p>
        </div>
        <button className="inline-flex items-center gap-2 rounded-full bg-gradient-primary text-primary-foreground px-6 py-2.5 text-sm font-semibold shadow-soft hover:shadow-glow transition-all">
          <Plus className="h-4 w-4" /> Schedule Visit
        </button>
      </div>

      <div className="grid lg:grid-cols-[1fr_350px] gap-8">
        <div className="space-y-8">
          <section>
            <h2 className="text-lg font-bold text-deep mb-4 flex items-center gap-2">
              <Clock className="h-5 w-5 text-primary" /> Upcoming Visits
            </h2>
            <div className="space-y-4">
              {loading ? (
                <div className="py-12 flex justify-center"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
              ) : upcoming.length === 0 ? (
                <p className="text-sm text-muted-foreground py-8 text-center italic">No upcoming visits scheduled</p>
              ) : (
                upcoming.map(app => (
                  <AppointmentCard key={app.id} appointment={app} />
                ))
              )}
            </div>
          </section>

          <section>
            <h2 className="text-lg font-bold text-deep mb-4 flex items-center gap-2 opacity-60">
              <CheckCircle2 className="h-5 w-5" /> Past Records
            </h2>
            <div className="space-y-4 opacity-70">
              {past.map(app => (
                <AppointmentCard key={app.id} appointment={app} isPast />
              ))}
            </div>
          </section>
        </div>

        <aside className="space-y-6">
          <Card className="rounded-3xl border-border shadow-soft bg-primary/5 border-primary/20">
            <CardHeader>
              <CardTitle className="text-deep flex items-center gap-2">
                <Bell className="h-5 w-5 text-primary" /> Smart Alerts
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <AlertItem 
                title="Vitals Overdue" 
                desc="Patient Jane Smith requires morning vital checks." 
                type="warning"
              />
              <AlertItem 
                title="Prescription Expiry" 
                desc="Dr. Brown's advice for Mr. John is expiring in 2 days." 
                type="info"
              />
              <AlertItem 
                title="New Application" 
                desc="A new caregiver application is pending review." 
                type="success"
              />
            </CardContent>
          </Card>

          <Card className="rounded-3xl border-border shadow-soft">
            <CardHeader>
              <CardTitle className="text-deep">Calendar Sync</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Connect your Google or Outlook calendar to automatically sync PrimeVita appointments.
              </p>
              <button className="w-full mt-4 py-2 text-xs font-bold uppercase tracking-widest border border-border rounded-xl hover:bg-secondary transition-colors">
                Connect Calendar
              </button>
            </CardContent>
          </Card>
        </aside>
      </div>
    </div>
  );
}

function AppointmentCard({ appointment, isPast }: { appointment: Appointment; isPast?: boolean }) {
  const date = new Date(appointment.scheduled_at);
  const day = date.getDate();
  const month = date.toLocaleString('default', { month: 'short' });
  const time = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <Card className={`rounded-[2rem] border-border shadow-soft overflow-hidden group hover:shadow-glow transition-all ${isPast ? "grayscale-[0.5]" : ""}`}>
      <CardContent className="p-0 flex flex-col md:flex-row">
        <div className={`p-6 md:w-32 flex flex-col items-center justify-center text-center ${isPast ? "bg-secondary text-muted-foreground" : "bg-gradient-primary text-primary-foreground"}`}>
          <span className="text-[10px] uppercase font-bold tracking-widest opacity-80">{month}</span>
          <span className="text-3xl font-display font-bold">{day}</span>
          <span className="text-[10px] font-semibold mt-1">{time}</span>
        </div>
        <div className="p-6 flex-1 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <h3 className="font-bold text-deep group-hover:text-primary transition-colors underline decoration-transparent group-hover:decoration-primary/30 underline-offset-4 decoration-2">
              Nursing Visit & Assessment
            </h3>
            <div className="flex flex-wrap gap-x-4 gap-y-1">
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <User className="h-3.5 w-3.5" />
                <span>Patient ID: {appointment.patient_id.slice(0, 8)}</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <MapPin className="h-3.5 w-3.5" />
                <span>Home Visit · Lagos</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="px-5 py-2 rounded-full border border-border text-xs font-bold text-deep hover:bg-secondary transition-colors">Reschedule</button>
            <button className="px-5 py-2 rounded-full bg-deep text-white text-xs font-bold hover:bg-black transition-all">Details</button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function AlertItem({ title, desc, type }: any) {
  const styles = {
    warning: "bg-amber-100 text-amber-700 border-amber-200",
    success: "bg-emerald-100 text-emerald-700 border-emerald-200",
    info: "bg-blue-100 text-blue-700 border-blue-200",
  };

  return (
    <div className={`p-4 rounded-2xl border ${styles[type as keyof typeof styles]} flex gap-3`}>
      <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
      <div>
        <h4 className="text-xs font-bold uppercase tracking-tight">{title}</h4>
        <p className="text-[11px] mt-0.5 leading-relaxed opacity-90">{desc}</p>
      </div>
    </div>
  );
}
