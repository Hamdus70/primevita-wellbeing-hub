
import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { 
  FileText, 
  CheckCircle2, 
  XCircle, 
  Eye, 
  Clock, 
  User, 
  Briefcase,
  Mail,
  Phone,
  ShieldCheck,
  Search,
  Loader2,
  Activity
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { toast } from "sonner";
import { Application } from "@/types/emr";

export const Route = createFileRoute("/dashboard/applications")({
  component: ApplicationsPage,
});

function ApplicationsPage() {
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    fetchApplications();
  }, [filter]);

  const fetchApplications = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('applications')
        .select('*')
        .order('created_at', { ascending: false });

      if (filter !== 'all') {
        query = query.eq('status', filter);
      }

      const { data, error } = await query;
      
      if (error) throw error;
      setApplications(data as Application[]);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAction = async (status: 'approved' | 'rejected') => {
    if (!selectedApp) return;
    setActionLoading(true);
    try {
      const { error } = await supabase
        .from('applications')
        .update({ status })
        .eq('id', selectedApp.id);

      if (error) throw error;

      if (status === 'approved') {
        if (selectedApp.type === 'staff') {
          // Create profile record (usually done by trigger or admin function)
          await supabase.from('profiles').insert({
            full_name: selectedApp.data.full_name,
            email: selectedApp.data.email,
            role: selectedApp.data.role_applying_for,
            phone: selectedApp.data.phone || "",
          });
        } else {
          await supabase.from('patients').insert({
            full_name: selectedApp.data.full_name,
            date_of_birth: selectedApp.data.date_of_birth || "",
            gender: selectedApp.data.gender || "",
            address: selectedApp.data.address || "",
            emergency_contact_phone: selectedApp.data.phone || "",
            status: 'active',
          });
        }
      }

      toast.success(`Application ${status} successfully`);
      setSelectedApp(null);
      fetchApplications();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-deep">Application Management</h1>
          <p className="text-muted-foreground text-sm">Review and manage intake forms for staff and patients</p>
        </div>
        <div className="flex items-center gap-2 bg-card border border-border p-1 rounded-xl shadow-soft">
          {['pending', 'approved', 'rejected', 'all'].map((t) => (
            <button
              key={t}
              onClick={() => setFilter(t as any)}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all ${
                filter === t 
                  ? "bg-gradient-primary text-primary-foreground shadow-soft" 
                  : "text-muted-foreground hover:bg-secondary"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="grid lg:grid-cols-[1fr_400px] gap-6">
        <div className="space-y-4">
          {loading ? (
            <div className="py-20 flex justify-center">
              <Loader2 className="h-8 w-8 text-primary animate-spin" />
            </div>
          ) : applications.length === 0 ? (
            <Card className="rounded-3xl border-dashed border-2 flex flex-col items-center justify-center py-20 text-muted-foreground">
              <FileText className="h-12 w-12 opacity-10 mb-4" />
              <p>No {filter} applications found</p>
            </Card>
          ) : (
            applications.map((app) => (
              <Card 
                key={app.id} 
                className={`rounded-2xl border-border shadow-soft transition-all cursor-pointer hover:border-primary/50 ${
                  selectedApp?.id === app.id ? "border-primary ring-1 ring-primary/20 bg-primary/5" : ""
                }`}
                onClick={() => setSelectedApp(app)}
              >
                <CardContent className="p-5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`h-12 w-12 rounded-xl flex items-center justify-center ${
                        app.type === 'staff' ? "bg-emerald-50 text-emerald-600" : "bg-blue-50 text-blue-600"
                      }`}>
                        {app.type === 'staff' ? <Briefcase className="h-6 w-6" /> : <User className="h-6 w-6" />}
                      </div>
                      <div>
                        <h3 className="font-semibold text-deep">{app.data.full_name}</h3>
                        <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                          <Mail className="h-3 w-3" /> {app.data.email}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        app.status === 'pending' ? "bg-amber-100 text-amber-700" :
                        app.status === 'approved' ? "bg-emerald-100 text-emerald-700" :
                        "bg-rose-100 text-rose-700"
                      }`}>
                        {app.status === 'pending' && <Clock className="h-3 w-3" />}
                        {app.status === 'approved' && <CheckCircle2 className="h-3 w-3" />}
                        {app.status === 'rejected' && <XCircle className="h-3 w-3" />}
                        {app.status}
                      </span>
                      <p className="text-[10px] text-muted-foreground mt-2">{new Date(app.created_at).toLocaleDateString()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        <div>
          {selectedApp ? (
            <Card className="rounded-3xl border-border shadow-glow sticky top-24 overflow-hidden">
              <CardHeader className="bg-secondary/20 p-6">
                <CardTitle className="text-deep flex items-center gap-2">
                  <Eye className="h-5 w-5 text-primary" /> Application Review
                </CardTitle>
                <div className="text-xs text-muted-foreground font-medium uppercase tracking-widest mt-1">
                  ID: {selectedApp.id.slice(0, 8)}...
                </div>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="space-y-4">
                  <DetailItem icon={User} label="Name" value={selectedApp.data.full_name} />
                  <DetailItem icon={Mail} label="Email" value={selectedApp.data.email} />
                  <DetailItem icon={Phone} label="Phone" value={selectedApp.data.phone} />
                  {selectedApp.type === 'staff' ? (
                    <>
                      <DetailItem icon={Briefcase} label="Role" value={selectedApp.data.role_applying_for} />
                      <DetailItem icon={ShieldCheck} label="Experience" value={selectedApp.data.years_of_experience + " years"} />
                    </>
                  ) : (
                    <>
                      <DetailItem icon={Activity} label="Interest" value={selectedApp.data.service_interested_in} />
                      <div className="space-y-1">
                        <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Medical Summary</p>
                        <p className="text-sm p-3 bg-secondary/30 rounded-xl leading-relaxed">{selectedApp.data.medical_condition_summary}</p>
                      </div>
                    </>
                  )}
                </div>

                {selectedApp.status === 'pending' && (
                  <div className="grid grid-cols-2 gap-3 pt-4 border-t border-border">
                    <button
                      disabled={actionLoading}
                      onClick={() => handleAction('rejected')}
                      className="py-3.5 rounded-xl border border-destructive text-destructive text-sm font-semibold hover:bg-destructive/5 transition-colors flex items-center justify-center gap-2"
                    >
                      {actionLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <><XCircle className="h-4 w-4" /> Reject</>}
                    </button>
                    <button
                      disabled={actionLoading}
                      onClick={() => handleAction('approved')}
                      className="py-3.5 rounded-xl bg-gradient-primary text-primary-foreground text-sm font-semibold shadow-soft hover:shadow-glow transition-all flex items-center justify-center gap-2"
                    >
                      {actionLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <><CheckCircle2 className="h-4 w-4" /> Approve</>}
                    </button>
                  </div>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="h-[400px] border-2 border-dashed border-border rounded-3xl flex flex-col items-center justify-center p-8 text-center text-muted-foreground">
              <Search className="h-12 w-12 opacity-10 mb-4" />
              <p className="font-semibold text-deep">No selection</p>
              <p className="text-xs mt-2">Select an application to view details and take action</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function DetailItem({ icon: Icon, label, value }: any) {
  return (
    <div className="flex items-start gap-3">
      <div className="mt-1 h-8 w-8 rounded-lg bg-secondary flex items-center justify-center text-primary">
        <Icon className="h-4 w-4" />
      </div>
      <div>
        <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{label}</p>
        <p className="text-sm font-semibold text-deep mt-0.5">{value}</p>
      </div>
    </div>
  );
}
