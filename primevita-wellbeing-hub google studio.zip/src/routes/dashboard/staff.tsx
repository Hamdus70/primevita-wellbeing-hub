
import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { 
  Users, 
  Search, 
  Plus, 
  Loader2,
  AlertCircle,
  MoreHorizontal,
  Mail,
  Calendar
} from "lucide-react";
import { 
  Card, 
  CardContent, 
} from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { Patient } from "@/types/emr";
import { toast } from "sonner";
import { motion } from "motion/react";

export const Route = createFileRoute("/dashboard/staff")({
  component: StaffDashboard,
});

function StaffDashboard() {
  const { profile } = useAuth();
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    if (profile) {
      fetchPatients();
    }
  }, [profile]);

  const fetchPatients = async () => {
    setLoading(true);
    try {
      let query = supabase.from('patients').select('*');
      
      if (profile?.role !== 'admin' && profile?.id) {
        query = query.contains('assigned_staff', [profile.id]);
      }

      const { data, error } = await query;
      if (error) throw error;
      setPatients((data || []) as Patient[]);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const filteredPatients = patients.filter(p => 
    p.full_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
         <h1 className="text-3xl font-display font-bold text-deep tracking-tight">Patients</h1>
         <div className="flex items-center gap-4">
            <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:text-primary transition-colors cursor-pointer">
               <Search className="h-5 w-5" />
            </div>
         </div>
      </div>

      <Card className="rounded-[2.5rem] border-border shadow-soft overflow-hidden">
        <div className="p-8 border-b border-border/50 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <h2 className="text-xl font-display font-bold text-deep">Electronic Health Records</h2>
          
          <div className="relative w-full md:w-80 group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-[#94A3B8] group-focus-within:text-primary transition-colors" />
            <input 
              type="text" 
              placeholder="Search patients..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-3 rounded-2xl border border-border bg-secondary/30 outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary focus:bg-background transition-all text-sm"
            />
          </div>
        </div>

        <CardContent className="p-0">
          {loading ? (
            <div className="py-24 flex flex-col items-center gap-4">
              <Loader2 className="h-10 w-10 text-primary animate-spin" />
              <p className="text-sm font-medium text-muted-foreground">Loading medical records...</p>
            </div>
          ) : filteredPatients.length === 0 ? (
            <div className="py-24 flex flex-col items-center justify-center text-muted-foreground px-8 text-center">
              <Users className="h-16 w-16 opacity-10 mb-6" />
              <h3 className="text-lg font-bold text-deep">No records found</h3>
              <p className="max-w-xs mx-auto mt-2 text-sm">We couldn't find any patient records matching your current criteria.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-border">
                    <th className="pl-8 py-6 text-[10px] font-bold uppercase tracking-widest text-muted-foreground w-1/3">Patient Name</th>
                    <th className="py-6 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">DOB</th>
                    <th className="py-6 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Status</th>
                    <th className="py-6 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Added</th>
                    <th className="pr-8 py-6 w-10"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  {filteredPatients.map((patient) => (
                    <tr key={patient.id} className="hover:bg-secondary/10 transition-colors group">
                      <td className="pl-8 py-6">
                        <div className="flex items-center gap-4">
                          <div className="h-10 w-10 rounded-full bg-gradient-primary flex items-center justify-center text-white font-bold text-xs">
                             {patient.full_name.charAt(0)}
                          </div>
                          <div>
                            <div className="text-sm font-bold text-deep">{patient.full_name}</div>
                            <div className="text-[10px] font-medium text-muted-foreground mt-0.5">{patient.email || "No email"}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-6">
                        <div className="text-sm font-medium text-[#64748B]">
                           {patient.date_of_birth ? new Date(patient.date_of_birth).toLocaleDateString() : "N/A"}
                        </div>
                      </td>
                      <td className="py-6">
                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                          patient.status === 'active' 
                            ? "bg-[#EBF7F4] text-primary" 
                            : "bg-amber-50 text-amber-600"
                        }`}>
                          {patient.status}
                        </span>
                      </td>
                      <td className="py-6">
                        <div className="text-sm font-medium text-[#64748B]">
                           {new Date(patient.created_at).toLocaleDateString()}
                        </div>
                      </td>
                      <td className="pr-8 py-6">
                        <button className="p-2 rounded-lg text-muted-foreground hover:bg-white hover:shadow-sm hover:text-deep transition-all">
                          <MoreHorizontal className="h-5 w-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
      
      {profile?.role === 'admin' && (
        <div className="flex justify-center">
           <button className="inline-flex items-center gap-2 rounded-full bg-deep text-white px-8 py-4 font-bold shadow-glow hover:translate-y-[-2px] transition-all">
              <Plus className="h-5 w-5" /> Register New Patient
           </button>
        </div>
      )}
    </div>
  );
}
