
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/dashboard/")({
  component: DashboardIndex,
});

function DashboardIndex() {
  const { profile, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && profile) {
      const role = profile.role;
      if (role === "admin") {
        navigate({ to: "/dashboard/admin" });
      } else if (role === "patient") {
        navigate({ to: "/dashboard/patient" });
      } else {
        navigate({ to: "/dashboard/staff" });
      }
    }
  }, [profile, loading, navigate]);

  return (
    <div className="flex items-center justify-center h-[60vh]">
      <Loader2 className="h-8 w-8 text-primary animate-spin" />
    </div>
  );
}
