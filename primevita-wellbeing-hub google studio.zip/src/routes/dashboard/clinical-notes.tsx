
import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { 
  FileText, 
  Plus, 
  Search, 
  User, 
  Calendar,
  Save,
  Loader2,
  Trash2,
  Filter,
  Droplet
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { Profile, Patient, DocumentationLog } from "@/types/emr";
import { toast } from "sonner";

export const Route = createFileRoute("/dashboard/clinical-notes")({
  component: ClinicalNotesPage,
});

function ClinicalNotesPage() {
  const { user, profile } = useAuth();
  const [patients, setPatients] = useState<Patient[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [logs, setLogs] = useState<DocumentationLog[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [noteContent, setNoteContent] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    fetchPatients();
  }, []);

  useEffect(() => {
    if (selectedPatient) {
      fetchLogs(selectedPatient.id);
    }
  }, [selectedPatient]);

  const fetchPatients = async () => {
    try {
      const { data, error } = await supabase.from('patients').select('*');
      if (error) throw error;
      setPatients(data as Patient[]);
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const fetchLogs = async (patientId: string) => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('documentation_logs')
        .select('*')
        .eq('patient_id', patientId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setLogs(data as DocumentationLog[]);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const [activeNoteType, setActiveNoteType] = useState<"note" | "diagnosis" | "prescription">("note");
  const [prescriptionData, setPrescriptionData] = useState({ drug: "", dosage: "", frequency: "", duration: "" });
  const [diagnosisData, setDiagnosisData] = useState({ code: "", description: "" });

  const handleSaveNote = async () => {
    if (!selectedPatient || !user) return;
    
    let content: any = {};
    if (activeNoteType === "note") {
      if (!noteContent.trim()) return;
      content = { note: noteContent };
    } else if (activeNoteType === "diagnosis") {
      if (!diagnosisData.description.trim()) return;
      content = diagnosisData;
    } else if (activeNoteType === "prescription") {
      if (!prescriptionData.drug.trim()) return;
      content = prescriptionData;
    }

    setIsSaving(true);
    try {
      const { error } = await supabase.from('documentation_logs').insert({
        patient_id: selectedPatient.id,
        staff_id: user.id,
        role: profile?.role || 'doctor',
        log_type: activeNoteType === 'note' ? 'clinical_note' : activeNoteType,
        content,
      });

      if (error) throw error;

      toast.success(`${activeNoteType.charAt(0).toUpperCase() + activeNoteType.slice(1)} saved`);
      setNoteContent("");
      setDiagnosisData({ code: "", description: "" });
      setPrescriptionData({ drug: "", dosage: "", frequency: "", duration: "" });
      fetchLogs(selectedPatient.id);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setIsSaving(false);
    }
  };

  const filteredPatients = patients.filter(p => 
    p.full_name?.toLowerCase().includes(search.toLowerCase())
  );

  if (profile?.role !== 'doctor' && profile?.role !== 'admin') {
    return <div className="p-12 text-center text-muted-foreground italic">Restricted to medical doctors and clinical administrators.</div>;
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold text-deep">Clinical Documentation</h1>
        <p className="text-muted-foreground text-sm">Clinical notes, observations and visit logs</p>
      </div>

      <div className="grid lg:grid-cols-[300px_1fr] gap-8">
        {/* Patient Selector */}
        <aside className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input 
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search patients..." 
              className="w-full bg-card border border-border rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>
          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
            {filteredPatients.map(p => (
              <button
                key={p.id}
                onClick={() => setSelectedPatient(p)}
                className={`w-full text-left p-4 rounded-2xl border transition-all ${selectedPatient?.id === p.id ? "bg-primary border-primary text-white shadow-glow" : "bg-card border-border hover:border-primary/50 text-deep"}`}
              >
                <div className="font-bold text-sm">{p.full_name}</div>
                <div className={`text-[10px] mt-1 opacity-70 ${selectedPatient?.id === p.id ? "text-white" : "text-muted-foreground"}`}>ID: {p.id.slice(0, 8)}</div>
              </button>
            ))}
          </div>
        </aside>

        {/* Notes Interface */}
        <main className="space-y-6">
          {!selectedPatient ? (
            <Card className="h-[400px] flex items-center justify-center text-center border-border/50 border-dashed">
              <div className="space-y-4 max-w-xs">
                <div className="mx-auto h-16 w-16 bg-secondary rounded-full flex items-center justify-center">
                  <User className="h-8 w-8 text-primary/40" />
                </div>
                <p className="text-muted-foreground font-medium">Select a patient to start documenting clinical notes.</p>
              </div>
            </Card>
          ) : (
            <>
              <Card className="rounded-[2.5rem] border-slate-200 shadow-soft overflow-hidden">
                <CardHeader className="bg-slate-50/50 border-b border-slate-100 p-0">
                   <div className="flex">
                      <NoteTab active={activeNoteType === 'note'} onClick={() => setActiveNoteType('note')} label="Progress Note" icon={<FileText className="h-4 w-4" />} />
                      <NoteTab active={activeNoteType === 'diagnosis'} onClick={() => setActiveNoteType('diagnosis')} label="Diagnosis" icon={<Activity className="h-4 w-4" />} />
                      <NoteTab active={activeNoteType === 'prescription'} onClick={() => setActiveNoteType('prescription')} label="Prescription" icon={<Droplet className="h-4 w-4" />} />
                   </div>
                </CardHeader>
                <CardContent className="p-8 space-y-6">
                  {activeNoteType === 'note' && (
                    <textarea 
                      value={noteContent}
                      onChange={e => setNoteContent(e.target.value)}
                      placeholder="Enter clinical observations, progress notes, and visit details..."
                      className="w-full min-h-[180px] p-6 rounded-[2rem] border border-slate-200 bg-slate-50/50 focus:outline-none focus:ring-4 focus:ring-primary/10 transition-all font-medium"
                    />
                  )}

                  {activeNoteType === 'diagnosis' && (
                    <div className="space-y-6">
                       <div className="grid md:grid-cols-3 gap-6">
                          <MiniNoteInput label="ICD CODE" placeholder="e.g. I10" value={diagnosisData.code} onChange={v => setDiagnosisData({...diagnosisData, code: v})} />
                          <div className="md:col-span-2">
                             <MiniNoteInput label="DIAGNOSIS DESCRIPTION" placeholder="Describe the diagnosed condition..." value={diagnosisData.description} onChange={v => setDiagnosisData({...diagnosisData, description: v})} />
                          </div>
                       </div>
                    </div>
                  )}

                  {activeNoteType === 'prescription' && (
                    <div className="space-y-6">
                       <div className="grid md:grid-cols-2 gap-6">
                          <MiniNoteInput label="DRUG NAME" placeholder="e.g. Paracetamol" value={prescriptionData.drug} onChange={v => setPrescriptionData({...prescriptionData, drug: v})} />
                          <MiniNoteInput label="DOSAGE" placeholder="e.g. 500mg" value={prescriptionData.dosage} onChange={v => setPrescriptionData({...prescriptionData, dosage: v})} />
                       </div>
                       <div className="grid md:grid-cols-2 gap-6">
                          <MiniNoteInput label="FREQUENCY" placeholder="e.g. 2x Daily" value={prescriptionData.frequency} onChange={v => setPrescriptionData({...prescriptionData, frequency: v})} />
                          <MiniNoteInput label="DURATION" placeholder="e.g. 7 Days" value={prescriptionData.duration} onChange={v => setPrescriptionData({...prescriptionData, duration: v})} />
                       </div>
                    </div>
                  )}

                  <div className="flex justify-end pt-4">
                    <button 
                      onClick={handleSaveNote}
                      disabled={isSaving}
                      className="inline-flex items-center gap-3 bg-primary text-white px-10 py-4 rounded-2xl text-sm font-black shadow-glow hover:bg-emerald-600 transition-all disabled:opacity-50 uppercase tracking-widest"
                    >
                      {isSaving ? <Loader2 className="h-5 w-5 animate-spin" /> : <Save className="h-5 w-5" />}
                      Finalize Entry
                    </button>
                  </div>
                </CardContent>
              </Card>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold text-deep">Documentation History</h2>
                  <button className="text-xs font-bold text-primary flex items-center gap-1">
                    <Filter className="h-3 w-3" /> Filter Labels
                  </button>
                </div>

                {isLoading ? (
                  <div className="py-12 flex justify-center"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
                ) : logs.length === 0 ? (
                  <p className="text-center text-muted-foreground py-12 italic border border-dashed rounded-3xl">No prior documentation found.</p>
                ) : (
                  <div className="space-y-4">
                    {logs.map((log: any) => (
                      <Card key={log.id} className="rounded-3xl border-border shadow-soft group hover:border-primary/20 transition-all">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex items-start gap-4">
                              <div className="h-10 w-10 rounded-xl bg-secondary flex items-center justify-center shrink-0">
                                <FileText className="h-5 w-5 text-primary" />
                              </div>
                              <div className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-deep capitalize">{(log.log_type as string).replace('_', ' ')}</span>
                                  <span className="text-[10px] px-2 py-0.5 bg-primary/10 text-primary rounded-full font-bold uppercase tracking-tight">{log.role}</span>
                                </div>
                                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                                  <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {new Date(log.created_at || '').toLocaleDateString()}</span>
                                  <span>·</span>
                                  <span>Dr. {log.staff_id?.slice(0, 8)}</span>
                                </div>
                                <div className="mt-4 text-sm text-foreground/80 leading-relaxed whitespace-pre-wrap">
                                  {log.content.note || JSON.stringify(log.content)}
                                </div>
                              </div>
                            </div>
                            <button className="opacity-0 group-hover:opacity-100 p-2 hover:bg-red-50 text-red-500 rounded-lg transition-all">
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </main>
      </div>
    </div>
  );
}

function NoteTab({ active, onClick, label, icon }: any) {
  return (
    <button 
      onClick={onClick}
      className={`flex-1 py-5 px-4 flex items-center justify-center gap-2 border-r border-slate-100 last:border-r-0 transition-all font-display font-bold text-xs uppercase tracking-widest ${active ? "bg-white text-primary" : "text-slate-400 hover:bg-slate-100"}`}
    >
      {icon}
      {label}
    </button>
  );
}

function MiniNoteInput({ label, placeholder, value, onChange }: any) {
  return (
    <div className="space-y-2">
      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">{label}</label>
      <input 
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full px-6 py-4 rounded-2xl border border-slate-200 bg-slate-50/50 focus:outline-none focus:ring-4 focus:ring-primary/10 transition-all font-bold text-deep text-sm"
      />
    </div>
  );
}
