
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { HeartPulse, Github, Mail, ArrowRight, ShieldCheck, Loader2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

function LoginPage() {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSignUp, setIsSignUp] = useState(false);
  const navigate = useNavigate();

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isSignUp) {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
        });
        
        if (error) throw error;

        // Note: Supabase usually handles profile creation via triggers, 
        // but we can ensure a record exists if not using triggers.
        if (data.user) {
          const { error: profileError } = await supabase.from("profiles").upsert({
            id: data.user.id,
            email: data.user.email,
            full_name: email.split('@')[0],
            role: "patient",
          });
          if (profileError) console.error("Profile creation error:", profileError);
        }

        toast.success("Registration successful! Please check your email.");
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        
        if (error) throw error;

        // Fetch role for redirection
        const { data: profile, error: profileError } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", data.user.id)
          .single();

        if (profileError) {
          console.error("Error fetching profile:", profileError);
          navigate({ to: "/dashboard" });
          return;
        }

        toast.success("Welcome back!");
        
        // Redirection logic based on role
        if (profile.role === 'admin') {
          navigate({ to: "/dashboard/admin" });
        } else if (profile.role === 'patient') {
          navigate({ to: "/dashboard/patient" });
        } else {
          navigate({ to: "/dashboard" });
        }
      }
    } catch (error: any) {
      toast.error(error.message || "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <SiteHeader />
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-card border border-border rounded-3xl shadow-glow overflow-hidden">
            <div className="bg-gradient-primary p-8 text-center text-primary-foreground relative">
              <div className="absolute top-0 right-0 p-4 opacity-20">
                <HeartPulse className="h-24 w-24" />
              </div>
              <div className="relative z-10">
                <h1 className="text-3xl font-display font-bold">
                  {isSignUp ? "Create Account" : "Welcome Back"}
                </h1>
                <p className="mt-2 text-primary-foreground/80 text-sm">
                  {isSignUp 
                    ? "Join PrimeVita for premium homecare management" 
                    : "Access your personalized health portal"}
                </p>
              </div>
            </div>

            <form onSubmit={handleAuth} className="p-8 space-y-5">
              <div className="space-y-2">
                <label className="text-sm font-medium text-deep flex items-center gap-2">
                  <Mail className="h-4 w-4" /> Email Address
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-border bg-background focus:ring-2 focus:ring-primary focus:border-transparent transition-all outline-none"
                  placeholder="name@example.com"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-deep flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4" /> Password
                </label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-border bg-background focus:ring-2 focus:ring-primary focus:border-transparent transition-all outline-none"
                  placeholder="••••••••"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 rounded-xl bg-gradient-primary text-primary-foreground font-semibold shadow-soft hover:shadow-glow transition-all flex items-center justify-center gap-2 disabled:opacity-70"
              >
                {loading ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <>
                    {isSignUp ? "Sign Up" : "Sign In"} <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </button>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-border"></span>
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-card px-2 text-muted-foreground">Or continue with</span>
                </div>
              </div>

              <button
                type="button"
                className="w-full py-3 rounded-xl border border-border hover:bg-secondary transition-colors text-sm font-medium flex items-center justify-center gap-2"
              >
                <Github className="h-4 w-4" /> GitHub
              </button>

              <div className="text-center pt-2">
                <p className="text-sm text-muted-foreground">
                  {isSignUp ? "Already have an account?" : "Don't have an account?"}{" "}
                  <button
                    type="button"
                    onClick={() => setIsSignUp(!isSignUp)}
                    className="text-primary font-semibold hover:underline"
                  >
                    {isSignUp ? "Sign In" : "Sign Up"}
                  </button>
                </p>
              </div>
            </form>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
