import { Link } from "@tanstack/react-router";
import { Phone, Menu, X, ChevronDown, User as UserIcon, LogIn, LayoutDashboard } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import logo from "@/assets/primevita-logo.png";

type NavItem = { to?: string; label: string; hasDropdown?: boolean; children?: Array<{ to: string; label: string; hash?: string }> };

const nav: NavItem[] = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { 
    label: "Services", 
    hasDropdown: true,
    children: [
      { to: "/services", hash: "skilled-nursing", label: "Skilled Nursing" },
      { to: "/services", hash: "personal-caregiving", label: "Personal Caregiving" },
      { to: "/services", hash: "physiotherapy", label: "Physiotherapy" },
      { to: "/services", hash: "post-operative", label: "Post-Operative Care" },
      { to: "/services", hash: "chronic-care", label: "Chronic Disease Management" },
      { to: "/services", hash: "dementia-care", label: "Dementia & Alzheimer's" },
    ]
  },
  { to: "/apply", label: "Portal" },
  { to: "/contact", label: "Contact" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState<string | null>(null);
  const { user, profile, loading } = useAuth();

  return (
    <header className="sticky top-0 z-50 w-full">
      <div className="bg-deep text-primary-foreground text-xs">
        <div className="mx-auto max-w-7xl px-4 py-2 flex items-center justify-between">
          <span className="hidden sm:inline tracking-wide uppercase">PrimeVita Health Services · Compassion meets expertise</span>
          <a href="tel:+18005551234" className="flex items-center gap-2 font-medium hover:opacity-80">
            <Phone className="h-3.5 w-3.5" /> +1 (800) 555-1234
          </a>
        </div>
      </div>
      <div className="bg-background/80 backdrop-blur border-b border-border">
        <div className="mx-auto max-w-7xl px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <img src={logo} alt="PrimeVita Health Services logo" width={44} height={44} className="h-11 w-11" />
            <div className="leading-tight">
              <div className="font-display text-lg font-semibold text-deep">PrimeVita</div>
              <div className="text-[10px] tracking-[0.2em] uppercase text-muted-foreground">Health Services</div>
            </div>
          </Link>
          <nav className="hidden md:flex items-center gap-8">
            {nav.map(n => n.hasDropdown ? (
              <div key={n.label} className="relative group">
                <button 
                  className="flex items-center gap-1 text-sm font-medium text-foreground/80 hover:text-primary transition-colors outline-none"
                >
                  {n.label} <ChevronDown className="h-3.5 w-3.5 transition-transform group-hover:rotate-180" />
                </button>
                <div className="absolute left-1/2 -translate-x-1/2 top-full pt-3 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 min-w-[240px]">
                  <div className="bg-card border border-border rounded-2xl shadow-glow overflow-hidden">
                    <div className="bg-gradient-primary px-4 py-2">
                      <p className="text-primary-foreground text-[10px] font-semibold uppercase tracking-widest">{n.label}</p>
                    </div>
                    <ul className="py-2">
                      {n.children?.map(s => (
                        <li key={s.label}>
                          <Link 
                            to={s.to as any} 
                            hash={s.hash} 
                            className="block px-5 py-2.5 text-sm text-foreground/80 hover:bg-secondary hover:text-primary transition-colors text-nowrap"
                          >
                            {s.label}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ) : (
              <Link key={n.to} to={n.to as any} className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors"
                activeProps={{ className: "text-primary" }} activeOptions={{ exact: n.to === "/" }}>
                {n.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-3">
            {!loading && (
              user ? (
                <Link 
                  to="/dashboard" 
                  className="inline-flex items-center gap-2 rounded-full bg-secondary text-secondary-foreground px-5 py-2.5 text-sm font-semibold hover:bg-secondary/80 transition-colors"
                >
                  <LayoutDashboard className="h-4 w-4" /> Dashboard
                </Link>
              ) : (
                <Link 
                  to="/login" 
                  className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 text-sm font-semibold text-foreground hover:bg-secondary transition-colors"
                >
                  <LogIn className="h-4 w-4" /> Login
                </Link>
              )
            )}
            <Link to="/contact" className="inline-flex items-center rounded-full bg-gradient-primary text-primary-foreground px-5 py-2.5 text-sm font-semibold shadow-soft hover:shadow-glow transition-shadow">
              Book a Visit
            </Link>
          </div>

          <button className="md:hidden p-2" onClick={() => setOpen(!open)} aria-label="Menu">
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {open && (
          <div className="md:hidden border-t border-border bg-background max-h-[80vh] overflow-y-auto">
            <div className="flex flex-col px-4 py-3 gap-1">
              {nav.map(n => n.hasDropdown ? (
                <div key={n.label}>
                  <button 
                    onClick={() => setDropdownOpen(dropdownOpen === n.label ? null : n.label)} 
                    className="w-full flex items-center justify-between py-2 text-foreground/80 font-medium"
                  >
                    {n.label} <ChevronDown className={`h-4 w-4 transition-transform ${dropdownOpen === n.label ? "rotate-180" : ""}`} />
                  </button>
                  {dropdownOpen === n.label && (
                    <div className="pl-4 pb-2 flex flex-col gap-1 border-l border-border ml-2">
                      {n.children?.map(s => (
                        <Link 
                          key={s.label} 
                          to={s.to as any} 
                          hash={s.hash} 
                          onClick={() => setOpen(false)} 
                          className="py-2 text-sm text-foreground/70 active:text-primary"
                        >
                          {s.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <Link 
                  key={n.to} 
                  to={n.to as any} 
                  onClick={() => setOpen(false)} 
                  className="py-2 text-foreground/80 font-medium active:text-primary"
                >
                  {n.label}
                </Link>
              ))}
              
              <div className="mt-4 flex flex-col gap-3">
                {user ? (
                  <Link 
                    to="/dashboard" 
                    onClick={() => setOpen(false)} 
                    className="flex items-center justify-center gap-2 py-3 rounded-xl bg-secondary text-secondary-foreground font-semibold"
                  >
                    <LayoutDashboard className="h-4 w-4" /> Dashboard
                  </Link>
                ) : (
                  <Link 
                    to="/login" 
                    onClick={() => setOpen(false)} 
                    className="flex items-center justify-center gap-2 py-3 rounded-xl border border-border text-foreground font-semibold"
                  >
                    <LogIn className="h-4 w-4" /> Login
                  </Link>
                )}
                <Link to="/contact" onClick={() => setOpen(false)} className="flex items-center justify-center py-3 rounded-xl bg-gradient-primary text-primary-foreground font-semibold">Book a Visit</Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
