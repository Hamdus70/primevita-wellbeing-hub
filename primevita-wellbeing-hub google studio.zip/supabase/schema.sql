
-- User Profiles and RBAC
CREATE TYPE user_role AS ENUM ('patient', 'doctor', 'nurse', 'physiotherapist', 'caregiver', 'admin');

CREATE TABLE profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  full_name TEXT NOT NULL,
  role user_role DEFAULT 'patient',
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Patients Table (Extended Info)
CREATE TABLE patients (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  profile_id UUID REFERENCES profiles(id) ON DELETE SET NULL, -- Null if not yet linked to an auth user
  full_name TEXT NOT NULL,
  date_of_birth DATE NOT NULL,
  gender TEXT,
  address TEXT,
  emergency_contact_name TEXT,
  emergency_contact_phone TEXT,
  blood_group TEXT,
  genotype TEXT,
  allergies TEXT[],
  medical_history TEXT,
  current_medications TEXT,
  assigned_staff UUID[] DEFAULT '{}', -- Array of staff profile IDs
  next_appointment_date TIMESTAMPTZ,
  hospital_name TEXT,
  clinic_type TEXT,
  status TEXT DEFAULT 'active', -- active, inactive, pending
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Documentation Logs (Unified)
CREATE TYPE log_type AS ENUM (
  'vital_signs', 
  'positioning', 
  'daily_activity', 
  'daily_report', 
  'clinical_note', 
  'physio_session', 
  'prescription',
  'doctor_advice'
);

CREATE TABLE documentation_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  patient_id UUID REFERENCES patients(id) ON DELETE CASCADE NOT NULL,
  staff_id UUID REFERENCES profiles(id) ON DELETE SET NULL NOT NULL,
  type log_type NOT NULL,
  
  -- Flexible Data Storage (JSONB for different log types)
  -- vital_signs: { temp, pulse, resp, bp, spo2, glucose }
  -- clinical_note: { note, severity, observation }
  -- prescription: { drugs: [{ name, dose, frequency, duration }] }
  -- physio_session: { arrival_time, exit_time, procedure_details }
  -- daily_activity: { mood, hygiene, meals, hydration }
  data JSONB NOT NULL,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Appointments
CREATE TABLE appointments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  patient_id UUID REFERENCES patients(id) ON DELETE CASCADE NOT NULL,
  staff_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  scheduled_at TIMESTAMPTZ NOT NULL,
  status TEXT DEFAULT 'scheduled', -- scheduled, completed, cancelled, missed
  location TEXT,
  clinic_type TEXT,
  notes TEXT,
  reminders_sent JSONB DEFAULT '{"2d": false, "1d": false, "0d": false}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Applications (Intake)
CREATE TYPE application_type AS ENUM ('staff', 'patient');
CREATE TYPE application_status AS ENUM ('pending', 'approved', 'rejected');

CREATE TABLE applications (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  type application_type NOT NULL,
  status application_status DEFAULT 'pending',
  data JSONB NOT NULL, -- Full intake form data
  reviewed_by UUID REFERENCES profiles(id),
  rejection_reason TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Row Level Security (RLS)

-- Profiles
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public profiles are viewable by everyone." ON profiles FOR SELECT USING (true);
CREATE POLICY "Users can insert their own profile." ON profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update own profile." ON profiles FOR UPDATE USING (auth.uid() = id);

-- Patients
ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Patients view own record" ON patients FOR SELECT USING (
  profile_id = auth.uid() OR 
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'doctor', 'nurse', 'physiotherapist', 'caregiver'))
);
CREATE POLICY "Staff assigned can view" ON patients FOR SELECT USING (
  auth.uid() = ANY(assigned_staff) OR
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);
CREATE POLICY "Admins can manage patients" ON patients FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);

-- Documentation Logs
ALTER TABLE documentation_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Patients view own logs" ON documentation_logs FOR SELECT USING (
  EXISTS (SELECT 1 FROM patients WHERE id = documentation_logs.patient_id AND profile_id = auth.uid())
);
CREATE POLICY "Staff view logs of assigned patients" ON documentation_logs FOR SELECT USING (
  EXISTS (SELECT 1 FROM patients WHERE id = documentation_logs.patient_id AND (auth.uid() = ANY(assigned_staff) OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')))
);
CREATE POLICY "Staff create logs" ON documentation_logs FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('doctor', 'nurse', 'physiotherapist', 'caregiver', 'admin'))
);

-- Appointments
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own appointments" ON appointments FOR SELECT USING (
  EXISTS (SELECT 1 FROM patients WHERE id = appointments.patient_id AND profile_id = auth.uid()) OR
  staff_id = auth.uid() OR
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);

-- Applications
ALTER TABLE applications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can create applications" ON applications FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can view applications" ON applications FOR SELECT USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);
CREATE POLICY "Admins can update applications" ON applications FOR UPDATE USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
);
